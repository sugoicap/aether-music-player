@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.pulseplayer

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed as gridItemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle

private enum class LibView(val label: String) {
    ARTISTS("Előadók"),
    ALBUMS("Albumok"),
    FOLDERS("Mappák"),
    SONGS("Összes szám")
}

private data class Group(
    val key: String,
    val title: String,
    val subtitle: String,
    val art: Any?,
    val tracks: List<Track>
)

private fun buildGroups(view: LibView, tracks: List<Track>): List<Group> = when (view) {
    LibView.ARTISTS -> tracks.groupBy { it.artist }.map { (artist, ts) ->
        val sorted = ts.sortedWith(compareBy({ it.album.lowercase() }, { it.trackNo }, { it.title.lowercase() }))
        Group("artist:$artist", artist, "${ts.size} szám", sorted.first().art, sorted)
    }.sortedBy { it.title.lowercase() }

    LibView.ALBUMS -> tracks.groupBy { it.albumId }.map { (id, ts) ->
        val sorted = ts.sortedWith(compareBy({ it.trackNo }, { it.title.lowercase() }))
        val artists = ts.map { it.artist }.distinct()
        Group(
            "album:$id",
            ts.first().album.ifBlank { "Ismeretlen album" },
            if (artists.size == 1) artists[0] else "Különböző előadók",
            sorted.first().art,
            sorted
        )
    }.sortedBy { it.title.lowercase() }

    LibView.FOLDERS -> tracks.groupBy { it.folderPath }.map { (path, ts) ->
        Group(
            "folder:$path",
            ts.first().folder,
            "${ts.size} szám · ${path.ifBlank { "/" }}",
            ts.first().art,
            ts.sortedBy { it.title.lowercase() }
        )
    }.sortedBy { it.title.lowercase() }

    LibView.SONGS -> emptyList()
}

@Composable
fun LibraryScreen(vm: PlayerViewModel) {
    val ctx = LocalContext.current
    val tracks by vm.tracks.collectAsStateWithLifecycle()
    val now by vm.now.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()

    val permission = if (Build.VERSION.SDK_INT >= 33) {
        Manifest.permission.READ_MEDIA_AUDIO
    } else {
        Manifest.permission.READ_EXTERNAL_STORAGE
    }
    var granted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, permission) == PackageManager.PERMISSION_GRANTED)
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    LaunchedEffect(granted) { if (granted) vm.loadLibrary() }

    if (!granted) {
        Column(
            Modifier
                .fillMaxSize()
                .padding(32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                Icons.Filled.LibraryMusic,
                contentDescription = null,
                modifier = Modifier.size(56.dp),
                tint = MaterialTheme.colorScheme.primary
            )
            Spacer(Modifier.height(16.dp))
            Text(
                "Játszd le a telefonodon lévő zenéket",
                style = MaterialTheme.typography.titleMedium,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(16.dp))
            Button(onClick = { launcher.launch(permission) }) { Text("Hozzáférés engedélyezése") }
        }
        return
    }

    var viewIdx by rememberSaveable { mutableStateOf(LibView.SONGS.ordinal) }
    var searchOpen by rememberSaveable { mutableStateOf(false) }
    var query by rememberSaveable { mutableStateOf("") }
    var openKey by rememberSaveable { mutableStateOf<String?>(null) }
    val focus = remember { FocusRequester() }
    LaunchedEffect(searchOpen) { if (searchOpen) focus.requestFocus() }

    val view = LibView.entries[viewIdx]
    val q = query.trim()

    // One search for every sub menu: a song matches by title, artist, album or folder name.
    val filtered = remember(tracks, q) {
        if (q.isEmpty()) tracks else tracks.filter {
            it.title.contains(q, ignoreCase = true) ||
                it.artist.contains(q, ignoreCase = true) ||
                it.album.contains(q, ignoreCase = true) ||
                it.folder.contains(q, ignoreCase = true)
        }
    }
    val groups = remember(filtered, view) { buildGroups(view, filtered) }
    val openGroup = openKey?.let { k -> groups.firstOrNull { it.key == k } }
    BackHandler(enabled = openGroup != null) { openKey = null }

    Column(Modifier.fillMaxSize()) {
        // Sub menus + magnifier
        Row(verticalAlignment = Alignment.CenterVertically) {
            LazyRow(
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(22.dp)
            ) {
                items(LibView.entries.toList()) { v ->
                    TextTab(v.label.uppercase(), v == view) {
                        viewIdx = v.ordinal
                        openKey = null
                    }
                }
            }
            IconButton(onClick = {
                searchOpen = !searchOpen
                if (!searchOpen) query = ""
            }) {
                Icon(
                    if (searchOpen) Icons.Filled.Close else Icons.Filled.Search,
                    contentDescription = if (searchOpen) "Keresés bezárása" else "Keresés"
                )
            }
        }

        if (searchOpen) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text("Szám, előadó, album vagy mappa") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
                    .focusRequester(focus)
            )
        }

        when {
            tracks.isEmpty() -> Text(
                "Nem található zene ezen az eszközön.",
                modifier = Modifier.padding(24.dp),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            filtered.isEmpty() -> Text(
                "Nincs találat.",
                modifier = Modifier.padding(24.dp),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            openGroup != null -> GroupDetail(vm, openGroup, now) { openKey = null }

            view == LibView.SONGS -> SongsView(vm, filtered, now, settings.listMode, settings.gridColumns)

            view == LibView.ALBUMS -> {
                Header("${groups.size} album", null)
                LazyVerticalGrid(
                    columns = GridCells.Fixed(settings.gridColumns),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    verticalArrangement = Arrangement.spacedBy(18.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    gridItemsIndexed(groups, key = { _, g -> g.key }) { _, g ->
                        GroupCard(g) { openKey = g.key }
                    }
                }
            }

            else -> {
                Header(
                    if (view == LibView.ARTISTS) "${groups.size} előadó" else "${groups.size} mappa",
                    null
                )
                LazyColumn(Modifier.fillMaxSize()) {
                    itemsIndexed(groups, key = { _, g -> g.key }) { _, g ->
                        GroupRow(g, round = view == LibView.ARTISTS) { openKey = g.key }
                    }
                }
            }
        }
    }
}

/** Upper-case sub menu entry with an accent underline when selected. */
@Composable
private fun TextTab(label: String, selected: Boolean, onClick: () -> Unit) {
    val line = MaterialTheme.colorScheme.primary
    Text(
        label,
        fontSize = 13.sp,
        fontWeight = FontWeight.SemiBold,
        letterSpacing = 1.5.sp,
        color = if (selected) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier
            .clickable(onClick = onClick)
            .drawBehind {
                if (selected) {
                    drawRect(
                        color = line,
                        topLeft = Offset(0f, size.height - 3.dp.toPx()),
                        size = Size(size.width, 3.dp.toPx())
                    )
                }
            }
            .padding(vertical = 14.dp)
    )
}

@Composable
private fun Header(label: String, onShuffle: (() -> Unit)?) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            label,
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.weight(1f)
        )
        if (onShuffle != null) {
            FilledTonalButton(onClick = onShuffle) {
                Icon(Icons.Filled.Shuffle, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("Keverés")
            }
        }
    }
}

@Composable
private fun SongsView(
    vm: PlayerViewModel,
    songs: List<Track>,
    now: NowPlaying,
    mode: ListMode,
    columns: Int
) {
    Header("${songs.size} szám") { vm.playLocal(songs, songs.indices.random(), shuffle = true) }
    if (mode == ListMode.GRID) {
        LazyVerticalGrid(
            columns = GridCells.Fixed(columns),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            gridItemsIndexed(songs, key = { _, t -> t.id }) { index, t ->
                val current = now.source == Source.LOCAL && now.mediaId == t.id.toString()
                TrackCard(t, current) { vm.playLocal(songs, index) }
            }
        }
    } else {
        LazyColumn(Modifier.fillMaxSize()) {
            itemsIndexed(songs, key = { _, t -> t.id }) { index, t ->
                val current = now.source == Source.LOCAL && now.mediaId == t.id.toString()
                TrackRow(t, current, detailed = mode == ListMode.DETAILED) { vm.playLocal(songs, index) }
            }
        }
    }
}

/** The songs of one artist / album / folder. */
@Composable
private fun GroupDetail(vm: PlayerViewModel, group: Group, now: NowPlaying, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(end = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Vissza")
            }
            Column(Modifier.weight(1f)) {
                Text(
                    group.title,
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    group.subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        Row(
            Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(onClick = { vm.playLocal(group.tracks, 0) }) {
                Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("Lejátszás")
            }
            FilledTonalButton(onClick = {
                vm.playLocal(group.tracks, group.tracks.indices.random(), shuffle = true)
            }) {
                Icon(Icons.Filled.Shuffle, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("Keverés")
            }
        }
        LazyColumn(Modifier.fillMaxSize()) {
            itemsIndexed(group.tracks, key = { _, t -> t.id }) { index, t ->
                val current = now.source == Source.LOCAL && now.mediaId == t.id.toString()
                TrackRow(t, current, detailed = false) { vm.playLocal(group.tracks, index) }
            }
        }
    }
}

@Composable
private fun GroupCard(g: Group, onClick: () -> Unit) {
    Column(
        Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
    ) {
        Art(g.art, Modifier.fillMaxWidth().aspectRatio(1f), RoundedCornerShape(12.dp))
        Spacer(Modifier.height(8.dp))
        Text(
            g.title,
            style = MaterialTheme.typography.titleSmall,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            g.subtitle,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun GroupRow(g: Group, round: Boolean, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Art(g.art, Modifier.size(52.dp), if (round) CircleShape else RoundedCornerShape(8.dp))
        Column(
            Modifier
                .weight(1f)
                .padding(horizontal = 14.dp)
        ) {
            Text(
                g.title,
                style = MaterialTheme.typography.titleMedium.copy(fontSize = 15.sp),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                g.subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun TrackCard(t: Track, current: Boolean, onClick: () -> Unit) {
    Column(
        Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
    ) {
        Box {
            Art(t.art, Modifier.fillMaxWidth().aspectRatio(1f), RoundedCornerShape(12.dp))
            Box(Modifier.align(Alignment.BottomStart).padding(6.dp)) { FormatBadge(t, overlay = true) }
        }
        Spacer(Modifier.height(8.dp))
        Text(
            t.title,
            style = MaterialTheme.typography.titleSmall,
            color = if (current) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            t.artist,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun TrackRow(t: Track, current: Boolean, detailed: Boolean, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = if (detailed) 10.dp else 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Artwork(t.art, if (detailed) 56.dp else 44.dp)
        Column(
            Modifier
                .weight(1f)
                .padding(horizontal = 14.dp)
        ) {
            Text(
                t.title,
                style = MaterialTheme.typography.titleMedium.copy(fontSize = 15.sp),
                color = if (current) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                if (detailed && t.album.isNotBlank()) "${t.artist} · ${t.album}" else t.artist,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (detailed) {
                Spacer(Modifier.height(4.dp))
                FormatBadge(t)
            }
        }
        Text(
            formatTime(t.durationMs),
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
