package com.example.pulseplayer

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Radio
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.rememberDrawerState
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.launch

enum class Tab(val label: String, val icon: ImageVector) {
    LIBRARY("Könyvtár", Icons.Filled.LibraryMusic),
    RADIO("Rádió", Icons.Filled.Radio)
}

@Composable
fun PulseApp(vm: PlayerViewModel) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val tab by vm.tab.collectAsStateWithLifecycle()
    val now by vm.now.collectAsStateWithLifecycle()
    val message by vm.message.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }

    var npOpen by rememberSaveable { mutableStateOf(false) }
    var settingsOpen by rememberSaveable { mutableStateOf(false) }

    val manual = Color(settings.manualAccent)
    val albumColor = rememberArtColor(now.artwork, manual)
    val accent = if (settings.accentMode == AccentMode.ALBUM && now.source != Source.NONE) albumColor else manual

    LaunchedEffect(message) {
        message?.let {
            snackbar.showSnackbar(it)
            vm.message.value = null
        }
    }
    BackHandler(enabled = npOpen) { npOpen = false }
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    PulseTheme(settings, accent) {
        Box(Modifier.fillMaxSize()) {
            ModalNavigationDrawer(
                drawerState = drawerState,
                drawerContent = {
                    DrawerContent(
                        selected = tab,
                        accent = accent,
                        onTab = {
                            vm.tab.value = it
                            scope.launch { drawerState.close() }
                        },
                        onSettings = {
                            settingsOpen = true
                            scope.launch { drawerState.close() }
                        }
                    )
                }
            ) {
                Scaffold(
                    containerColor = MaterialTheme.colorScheme.background,
                    topBar = { TopBar(tab.label) { scope.launch { drawerState.open() } } },
                    snackbarHost = { SnackbarHost(snackbar) },
                    bottomBar = {
                        if (now.source != Source.NONE) MiniPlayer(now, accent, vm) { npOpen = true }
                    }
                ) { padding ->
                    Box(
                        Modifier
                            .padding(padding)
                            .fillMaxSize()
                    ) {
                        when (tab) {
                            Tab.LIBRARY -> LibraryScreen(vm)
                            Tab.RADIO -> RadioScreen(vm)
                        }
                    }
                }
            }

            AnimatedVisibility(
                visible = npOpen && now.source != Source.NONE,
                enter = slideInVertically(tween(350)) { it } + fadeIn(tween(250)),
                exit = slideOutVertically(tween(300)) { it } + fadeOut(tween(200))
            ) {
                NowPlayingScreen(
                    vm = vm,
                    settings = settings,
                    accent = accent,
                    onClose = { npOpen = false },
                    onSettings = { settingsOpen = true }
                )
            }

            if (settingsOpen) {
                SettingsSheet(settings, onChange = vm::updateSettings, onDismiss = { settingsOpen = false })
            }
        }
    }
}

@Composable
private fun TopBar(title: String, onMenu: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .height(56.dp)
            .padding(start = 4.dp, end = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onMenu) {
            Icon(Icons.Filled.Menu, contentDescription = "Menü")
        }
        Text(title, style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
    }
}

@Composable
private fun DrawerContent(selected: Tab, accent: Color, onTab: (Tab) -> Unit, onSettings: () -> Unit) {
    ModalDrawerSheet(drawerContainerColor = MaterialTheme.colorScheme.surfaceContainerHigh) {
        Spacer(Modifier.statusBarsPadding().height(28.dp))
        Text(
            "NAVIGÁCIÓ",
            style = MaterialTheme.typography.labelLarge,
            letterSpacing = 1.sp,
            color = accent,
            modifier = Modifier.padding(start = 24.dp, bottom = 16.dp)
        )
        Tab.entries.forEach { t ->
            DrawerItem(t.label, selected == t, accent) { onTab(t) }
        }
        DrawerItem("Beállítások", false, accent, onSettings)
    }
}

@Composable
private fun DrawerItem(label: String, selected: Boolean, accent: Color, onClick: () -> Unit) {
    Box(
        Modifier
            .fillMaxWidth()
            .padding(end = 12.dp, top = 2.dp, bottom = 2.dp)
            .height(56.dp)
            .clip(RoundedCornerShape(topEnd = 28.dp, bottomEnd = 28.dp))
            .background(if (selected) MaterialTheme.colorScheme.surfaceVariant else Color.Transparent)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.CenterStart
    ) {
        if (selected) {
            Box(
                Modifier
                    .width(4.dp)
                    .fillMaxHeight()
                    .background(accent)
            )
        }
        Text(
            label,
            fontSize = 20.sp,
            fontWeight = if (selected) FontWeight.Medium else FontWeight.Normal,
            color = if (selected) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(start = 28.dp)
        )
    }
}

@Composable
private fun MiniPlayer(now: NowPlaying, accent: Color, vm: PlayerViewModel, onOpen: () -> Unit) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 6.dp)
    ) {
        Column(Modifier.clickable(onClick = onOpen)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(start = 10.dp, end = 4.dp, top = 8.dp, bottom = 6.dp)
            ) {
                Artwork(now.artwork, 44.dp)
                Column(
                    Modifier
                        .weight(1f)
                        .padding(horizontal = 12.dp)
                ) {
                    Text(
                        now.title,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.titleSmall
                    )
                    Text(
                        if (now.source == Source.RADIO && now.subtitle.isBlank()) "Live radio" else now.subtitle,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = vm::previous) {
                    Icon(Icons.Filled.SkipPrevious, contentDescription = "Previous")
                }
                IconButton(onClick = vm::togglePlayPause) {
                    Icon(
                        if (now.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                        contentDescription = if (now.isPlaying) "Pause" else "Play",
                        modifier = Modifier.size(30.dp)
                    )
                }
                IconButton(onClick = vm::next) {
                    Icon(Icons.Filled.SkipNext, contentDescription = "Next")
                }
            }
            val fraction = if (now.durationMs > 0) (now.positionMs.toFloat() / now.durationMs).coerceIn(0f, 1f) else 0f
            LinearProgressIndicator(
                progress = { fraction },
                color = accent,
                trackColor = Color.White.copy(alpha = 0.08f),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(2.dp)
            )
        }
    }
}
