# PulsePlayer

An Android music player (Kotlin + Jetpack Compose + Media3) with two sources:

- **Library**: songs stored on your phone, browsable by Artists, Albums, Folders or All songs, with one magnifier search. Shuffle, grid / compact / detailed views, FLAC/MP3 + bitrate badges, background playback with notification and lock-screen controls.
- **Radio**: thousands of online stations from the free [Radio Browser](https://www.radio-browser.info) directory. Search, genre chips, favorites, live song title when the station sends it.

## Design

- OLED true black theme, Inter font, accent colour from the album cover or a colour you pick.
- Now Playing screen (tap the mini player): Classic, Minimal and Vinyl layouts, blurred cover background,
  adjustable cover corner radius, waveform seek bar, slide/fade transitions.
- Everything is adjustable in Settings (gear icon, top right).
- The Inter font is downloaded automatically during the build.

## Build

Open the folder in Android Studio and run, or use the GitHub Actions workflow (see `.github/workflows/build.yml`).
Needs Android 8.0 (API 26) or newer.

## Project layout

```
app/src/main/java/com/example/pulseplayer/
  MainActivity.kt        entry point
  PlaybackService.kt     Media3 background service
  PlayerViewModel.kt     controls playback
  Data.kt                MediaStore, Radio Browser API, saved favourites
  PulseApp.kt            navigation, mini player
  NowPlayingScreen.kt    full player (layouts, waveform, swipe to change song)
  LibraryScreen.kt / RadioScreen.kt / SettingsSheet.kt
  Theme.kt / Art.kt / Waveform.kt / Components.kt / Settings.kt
```
