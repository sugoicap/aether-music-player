package com.example.pulseplayer

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.sqrt
import kotlin.random.Random

/** Reads a local audio file and returns the loudness of ~90 slices of it (0..1). */
object WaveformRepository {
    private const val BARS = 90
    private val cache = HashMap<String, FloatArray>()

    suspend fun load(context: Context, uri: Uri): FloatArray? = withContext(Dispatchers.IO) {
        val key = uri.toString()
        synchronized(cache) { cache[key] }?.let { return@withContext it }
        val result = try {
            decode(context, uri)
        } catch (_: Throwable) {
            null
        }
        if (result != null) synchronized(cache) { cache[key] = result }
        result
    }

    private fun decode(context: Context, uri: Uri): FloatArray? {
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            extractor.setDataSource(context, uri, null)
            var trackIndex = -1
            var format: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                if (f.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) {
                    trackIndex = i
                    format = f
                    break
                }
            }
            if (trackIndex < 0 || format == null) return null
            val mime = format.getString(MediaFormat.KEY_MIME) ?: return null
            val durationUs =
                if (format.containsKey(MediaFormat.KEY_DURATION)) format.getLong(MediaFormat.KEY_DURATION) else 0L
            if (durationUs <= 0L) return null

            extractor.selectTrack(trackIndex)
            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(format, null, null, 0)
            codec.start()

            val peaks = FloatArray(BARS)
            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            val deadline = System.nanoTime() + 25_000_000_000L

            while (!outputDone) {
                if (System.nanoTime() > deadline) return null
                if (!inputDone) {
                    val inIndex = codec.dequeueInputBuffer(5_000)
                    if (inIndex >= 0) {
                        val buf = codec.getInputBuffer(inIndex)
                        val size = if (buf != null) extractor.readSampleData(buf, 0) else -1
                        if (size < 0) {
                            codec.queueInputBuffer(inIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(inIndex, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }
                val outIndex = codec.dequeueOutputBuffer(info, 5_000)
                if (outIndex >= 0) {
                    val out = codec.getOutputBuffer(outIndex)
                    if (out != null && info.size > 0) {
                        out.position(info.offset)
                        out.limit(info.offset + info.size)
                        val shorts = out.order(ByteOrder.nativeOrder()).asShortBuffer()
                        val bar = (info.presentationTimeUs * BARS / durationUs).toInt().coerceIn(0, BARS - 1)
                        var peak = 0
                        var k = 0
                        while (k < shorts.limit()) {
                            val v = abs(shorts.get(k).toInt())
                            if (v > peak) peak = v
                            k += 8
                        }
                        if (peak > peaks[bar]) peaks[bar] = peak.toFloat()
                    }
                    codec.releaseOutputBuffer(outIndex, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
                }
            }

            val max = peaks.maxOrNull() ?: 0f
            if (max <= 0f) return null
            return FloatArray(BARS) { i -> (sqrt(peaks[i] / max)).coerceIn(0.12f, 1f) }
        } finally {
            try {
                codec?.stop()
            } catch (_: Throwable) {
            }
            codec?.release()
            extractor.release()
        }
    }
}

/**
 * Waveform used as a seek bar. Tap or drag to jump. If [peaks] is null (not a local file, or not
 * decoded yet) a soft decorative pattern is drawn instead.
 */
@Composable
fun WaveformSeek(
    peaks: FloatArray?,
    progress: Float,
    accent: Color,
    seed: Long,
    enabled: Boolean,
    onSeek: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val bars = remember(peaks, seed) {
        peaks ?: FloatArray(90).also {
            val r = Random(seed)
            var v = 0.5f
            for (i in it.indices) {
                v = (v + (r.nextFloat() - 0.5f) * 0.5f).coerceIn(0.2f, 1f)
                it[i] = v
            }
        }
    }
    var drag by remember { mutableStateOf<Float?>(null) }
    val shown = drag ?: progress
    val rest = Color.White.copy(alpha = 0.22f)

    Canvas(
        modifier
            .pointerInput(enabled) {
                if (enabled) {
                    detectTapGestures { o -> onSeek((o.x / size.width).coerceIn(0f, 1f)) }
                }
            }
            .pointerInput(enabled) {
                if (enabled) {
                    detectHorizontalDragGestures(
                        onDragStart = { drag = (it.x / size.width).coerceIn(0f, 1f) },
                        onDragEnd = {
                            drag?.let(onSeek)
                            drag = null
                        },
                        onDragCancel = { drag = null },
                        onHorizontalDrag = { change, _ ->
                            drag = (change.position.x / size.width).coerceIn(0f, 1f)
                        }
                    )
                }
            }
    ) {
        val n = bars.size
        val gap = 3.dp.toPx()
        val barW = (size.width - gap * (n - 1)) / n
        val minH = 4.dp.toPx()
        for (i in 0 until n) {
            val h = (size.height * bars[i]).coerceAtLeast(minH)
            drawRoundRect(
                color = if ((i + 0.5f) / n <= shown) accent else rest,
                topLeft = Offset(i * (barW + gap), (size.height - h) / 2f),
                size = Size(barW, h),
                cornerRadius = CornerRadius(barW / 2f)
            )
        }
    }
}
