package com.example.pulseplayer

import android.app.Application
import android.content.ComponentName
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/**
 * Owns playback for both sources (local music and online radio). Both play through Media3
 * in a background service. Starting one replaces the other.
 */
class PlayerViewModel(private val app: Application) : AndroidViewModel(app) {

    private val store = Store(app)
    private val settingsStore = SettingsStore(app)
    val settings = MutableStateFlow(settingsStore.load())

    val tab = MutableStateFlow(Tab.LIBRARY)
    val tracks = MutableStateFlow<List<Track>>(emptyList())
    val stations = MutableStateFlow<List<Station>>(emptyList())
    val favorites = MutableStateFlow(store.loadFavorites())
    val radioLoading = MutableStateFlow(false)
    val radioError = MutableStateFlow<String?>(null)
    val now = MutableStateFlow(NowPlaying())
    val message = MutableStateFlow<String?>(null)

    private var controller: MediaController? = null
    private var radioList: List<Station> = emptyList()
    private var radioIndex = -1
    private var radioJob: Job? = null

    private val playerListener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) {
            refreshFromController()
        }

        override fun onPlayerError(error: PlaybackException) {
            message.value = "Playback error: ${error.errorCodeName}"
        }
    }

    init {
        val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
        val future = MediaController.Builder(app, token).buildAsync()
        future.addListener({
            try {
                controller = future.get().also { it.addListener(playerListener) }
            } catch (e: Exception) {
                message.value = "Couldn't connect to the audio service"
            }
        }, ContextCompat.getMainExecutor(app))

        // Progress ticker
        viewModelScope.launch {
            while (true) {
                delay(250)
                val c = controller ?: continue
                val s = now.value.source
                if (s == Source.LOCAL || s == Source.RADIO) {
                    now.update {
                        it.copy(
                            positionMs = c.currentPosition.coerceAtLeast(0L),
                            durationMs = if (s == Source.LOCAL) c.duration.coerceAtLeast(0L) else 0L
                        )
                    }
                }
            }
        }
    }

    // ---------- Settings ----------

    fun updateSettings(s: AppSettings) {
        settings.value = s
        settingsStore.save(s)
    }

    // ---------- Library ----------

    fun loadLibrary() {
        viewModelScope.launch {
            try {
                tracks.value = LocalMusicRepository.load(app)
            } catch (e: Exception) {
                message.value = "Couldn't read your music library"
            }
        }
    }

    fun playLocal(list: List<Track>, index: Int, shuffle: Boolean = false) {
        val c = controller ?: run {
            message.value = "Player is still starting, try again"
            return
        }
        if (list.isEmpty()) return
        now.value = NowPlaying(Source.LOCAL)
        c.shuffleModeEnabled = shuffle
        c.repeatMode = Player.REPEAT_MODE_ALL
        c.setMediaItems(list.map { it.toMediaItem() }, index.coerceIn(list.indices), 0L)
        c.prepare()
        c.play()
        refreshFromController()
    }

    // ---------- Radio ----------

    fun searchRadio(query: String, tag: String?) {
        radioJob?.cancel()
        radioJob = viewModelScope.launch {
            radioLoading.value = true
            radioError.value = null
            try {
                stations.value = RadioRepository.search(query.trim(), tag)
            } catch (e: Exception) {
                radioError.value = "Couldn't reach the radio directory. Check your connection."
            }
            radioLoading.value = false
        }
    }

    fun playStation(list: List<Station>, index: Int) {
        val c = controller ?: run {
            message.value = "Player is still starting, try again"
            return
        }
        val station = list.getOrNull(index) ?: return
        radioList = list
        radioIndex = index
        now.value = NowPlaying(Source.RADIO, mediaId = station.id, title = station.name, subtitle = station.subtitle)
        c.shuffleModeEnabled = false
        c.repeatMode = Player.REPEAT_MODE_OFF
        c.setMediaItem(station.toMediaItem())
        c.prepare()
        c.play()
        viewModelScope.launch { RadioRepository.countClick(station.id) }
    }

    fun toggleFavorite(station: Station) {
        favorites.update { list ->
            if (list.any { it.id == station.id }) list.filterNot { it.id == station.id } else list + station
        }
        store.saveFavorites(favorites.value)
    }

    // ---------- Transport controls ----------

    fun togglePlayPause() {
        controller?.let {
            if (it.playWhenReady && it.playbackState != Player.STATE_ENDED) it.pause() else it.play()
        }
    }

    fun next() {
        when (now.value.source) {
            Source.LOCAL -> controller?.seekToNextMediaItem()
            Source.RADIO -> if (radioList.isNotEmpty()) playStation(radioList, (radioIndex + 1) % radioList.size)
            Source.NONE -> {}
        }
    }

    fun previous() {
        when (now.value.source) {
            Source.LOCAL -> controller?.seekToPrevious()
            Source.RADIO -> if (radioList.isNotEmpty()) {
                playStation(radioList, (radioIndex - 1 + radioList.size) % radioList.size)
            }
            Source.NONE -> {}
        }
    }

    fun seekTo(ms: Long) {
        if (now.value.source == Source.LOCAL) controller?.seekTo(ms)
    }

    fun toggleShuffle() {
        val c = controller ?: return
        c.shuffleModeEnabled = !c.shuffleModeEnabled
        refreshFromController()
    }

    fun cycleRepeat() {
        val c = controller ?: return
        c.repeatMode = when (c.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
        refreshFromController()
    }

    // ---------- Internals ----------

    private fun refreshFromController() {
        val c = controller ?: return
        val source = now.value.source
        if (source == Source.NONE) return

        val meta = c.mediaMetadata
        val active = c.playWhenReady &&
            c.playbackState != Player.STATE_ENDED &&
            c.playbackState != Player.STATE_IDLE
        val id = c.currentMediaItem?.mediaId.orEmpty()

        if (source == Source.LOCAL) {
            now.update {
                it.copy(
                    mediaId = id,
                    title = meta.title?.toString().orEmpty(),
                    subtitle = meta.artist?.toString().orEmpty(),
                    artwork = c.currentMediaItem?.localConfiguration?.uri?.let { u -> LocalArt(u) },
                    shuffle = c.shuffleModeEnabled,
                    repeat = c.repeatMode,
                    isPlaying = active
                )
            }
        } else {
            val station = radioList.getOrNull(radioIndex)
            // Radio streams push the current song title as live metadata
            val live = meta.title?.toString().orEmpty()
            now.update {
                it.copy(
                    mediaId = id,
                    title = station?.name ?: live,
                    subtitle = if (live.isNotBlank() && live != station?.name) live else station?.subtitle.orEmpty(),
                    artwork = station?.favicon?.takeIf { f -> f.isNotBlank() },
                    isPlaying = active
                )
            }
        }
    }

    override fun onCleared() {
        controller?.release()
        super.onCleared()
    }
}
