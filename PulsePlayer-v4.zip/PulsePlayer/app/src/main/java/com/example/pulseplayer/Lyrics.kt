package com.example.pulseplayer

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import kotlin.math.abs

data class LrcLine(val timeMs: Long, val text: String)
data class Lyrics(val lines: List<LrcLine>, val synced: Boolean)

/** Time-synced lyrics from the free LRCLIB service (lrclib.net, no key needed). */
object LyricsRepository {
    private val cache = HashMap<String, Lyrics?>()
    private val stamp = Regex("\\[(\\d{1,2}):(\\d{2})(?:[.:](\\d{1,3}))?]")

    /** Returns null if nothing was found or the network failed. */
    suspend fun load(key: String, artist: String, title: String, durationMs: Long): Lyrics? =
        withContext(Dispatchers.IO) {
            synchronized(cache) { if (cache.containsKey(key)) return@withContext cache[key] }
            val found = try {
                fetch(artist, title, durationMs)
            } catch (_: Exception) {
                return@withContext null
            }
            synchronized(cache) { cache[key] = found }
            found
        }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun str(o: JSONObject, key: String): String = if (o.isNull(key)) "" else o.optString(key, "")

    private fun fetch(artist: String, title: String, durationMs: Long): Lyrics? {
        val cleanArtist = if (artist.equals("Unknown artist", ignoreCase = true)) "" else artist
        var url = "https://lrclib.net/api/search?track_name=${enc(title)}"
        if (cleanArtist.isNotBlank()) url += "&artist_name=${enc(cleanArtist)}"
        val arr = JSONArray(httpGet(url))

        var best: JSONObject? = null
        var bestDiff = Long.MAX_VALUE
        var plain: String? = null
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val diff = abs((o.optDouble("duration", 0.0) * 1000).toLong() - durationMs)
            if (str(o, "syncedLyrics").isNotBlank() && diff < bestDiff) {
                best = o
                bestDiff = diff
            }
            if (plain == null && str(o, "plainLyrics").isNotBlank()) plain = str(o, "plainLyrics")
        }
        if (best != null && bestDiff < 10_000) {
            val lines = parse(str(best, "syncedLyrics"))
            if (lines.isNotEmpty()) return Lyrics(lines, true)
        }
        if (plain != null) {
            return Lyrics(plain.lines().map { LrcLine(-1, it.trim()) }, false)
        }
        return null
    }

    private fun parse(text: String): List<LrcLine> {
        val out = ArrayList<LrcLine>()
        for (raw in text.lines()) {
            val matches = stamp.findAll(raw).toList()
            if (matches.isEmpty()) continue
            val content = raw.substring(matches.last().range.last + 1).trim()
            for (m in matches) {
                val min = m.groupValues[1].toLong()
                val sec = m.groupValues[2].toLong()
                val frac = m.groupValues[3]
                val ms = if (frac.isEmpty()) 0L else frac.padEnd(3, '0').take(3).toLong()
                out += LrcLine(min * 60_000 + sec * 1000 + ms, content)
            }
        }
        out.sortBy { it.timeMs }
        return out
    }
}
