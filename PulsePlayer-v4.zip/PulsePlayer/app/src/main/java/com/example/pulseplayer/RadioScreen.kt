package com.example.pulseplayer

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Radio
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle

private val genres = listOf("pop", "rock", "jazz", "classical", "electronic", "hip hop", "news", "chillout")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RadioScreen(vm: PlayerViewModel) {
    val stations by vm.stations.collectAsStateWithLifecycle()
    val favorites by vm.favorites.collectAsStateWithLifecycle()
    val loading by vm.radioLoading.collectAsStateWithLifecycle()
    val error by vm.radioError.collectAsStateWithLifecycle()
    val now by vm.now.collectAsStateWithLifecycle()

    var query by rememberSaveable { mutableStateOf("") }
    var tag by rememberSaveable { mutableStateOf<String?>(null) }
    var showFavorites by rememberSaveable { mutableStateOf(false) }

    LaunchedEffect(Unit) { if (stations.isEmpty()) vm.searchRadio("", null) }

    val list = if (showFavorites) favorites else stations

    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            placeholder = { Text("Search radio stations") },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
            singleLine = true,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = {
                showFavorites = false
                vm.searchRadio(query, tag)
            }),
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        )

        LazyRow(
            contentPadding = PaddingValues(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                FilterChip(
                    selected = showFavorites,
                    onClick = { showFavorites = !showFavorites },
                    label = { Text("Favorites") },
                    leadingIcon = { Icon(Icons.Filled.Favorite, contentDescription = null, modifier = Modifier.size(18.dp)) }
                )
            }
            items(genres) { genre ->
                FilterChip(
                    selected = tag == genre && !showFavorites,
                    onClick = {
                        val newTag = if (tag == genre) null else genre
                        tag = newTag
                        showFavorites = false
                        vm.searchRadio(query, newTag)
                    },
                    label = { Text(genre.replaceFirstChar { it.uppercase() }) }
                )
            }
        }

        if (loading) {
            LinearProgressIndicator(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp)
            )
        }

        if (!showFavorites && error != null) {
            Column(Modifier.padding(24.dp)) {
                Text(error.orEmpty(), color = MaterialTheme.colorScheme.error)
                TextButton(onClick = { vm.searchRadio(query, tag) }) { Text("Retry") }
            }
        } else if (list.isEmpty() && !loading) {
            Text(
                if (showFavorites) "Tap the heart on a station to keep it here." else "No stations found.",
                modifier = Modifier.padding(24.dp),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                itemsIndexed(list, key = { _, s -> s.id }) { index, station ->
                    val current = now.source == Source.RADIO && now.mediaId == station.id
                    val isFavorite = favorites.any { it.id == station.id }
                    ListItem(
                        modifier = Modifier.clickable { vm.playStation(list, index) },
                        colors = ListItemDefaults.colors(
                            containerColor = if (current) MaterialTheme.colorScheme.secondaryContainer else Color.Transparent
                        ),
                        leadingContent = { Artwork(station.favicon, 48.dp, Icons.Filled.Radio) },
                        headlineContent = { Text(station.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                        supportingContent = {
                            Text(station.subtitle, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        },
                        trailingContent = {
                            IconButton(onClick = { vm.toggleFavorite(station) }) {
                                Icon(
                                    if (isFavorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                                    contentDescription = if (isFavorite) "Remove from favorites" else "Add to favorites",
                                    tint = if (isFavorite) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    )
                }
            }
        }
    }
}
