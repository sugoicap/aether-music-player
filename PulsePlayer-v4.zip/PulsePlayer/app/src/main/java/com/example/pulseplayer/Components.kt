package com.example.pulseplayer

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage

/** Cover image with a quiet icon behind it, shown while loading or when there is no image. */
@Composable
fun Art(
    model: Any?,
    modifier: Modifier,
    shape: Shape = RoundedCornerShape(8.dp),
    fallback: ImageVector = Icons.Filled.MusicNote
) {
    Box(
        modifier
            .clip(shape)
            .background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            fallback,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
            modifier = Modifier.size(24.dp)
        )
        val empty = model == null || (model is String && model.isBlank())
        if (!empty) {
            AsyncImage(
                model = model,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

@Composable
fun Artwork(url: Any?, size: Dp, fallback: ImageVector = Icons.Filled.MusicNote) {
    Art(url, Modifier.size(size), RoundedCornerShape(8.dp), fallback)
}

/** Small "FLAC" / "MP3 · 320k" label. Lossless formats use the accent colour. */
@Composable
fun FormatBadge(track: Track, overlay: Boolean = false) {
    val label = buildString {
        append(track.format.ifBlank { "AUDIO" })
        if (track.bitrateKbps > 0) append(" · ${track.bitrateKbps}k")
    }
    val lossless = track.format in setOf("FLAC", "WAV", "ALAC", "AIFF")
    val color = if (lossless) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
    Text(
        label,
        fontSize = 10.sp,
        fontWeight = FontWeight.SemiBold,
        color = color,
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(if (overlay) Color.Black.copy(alpha = 0.7f) else Color.Transparent)
            .border(1.dp, color.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
            .padding(horizontal = 5.dp, vertical = 1.dp)
    )
}
