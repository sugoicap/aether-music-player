package com.example.pulseplayer

import android.os.Build
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.ContentTransform
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.Player
import coil.compose.AsyncImage
import kotlin.math.max

private data class TrackView(val id: String, val title: String, val subtitle: String, val art: Any?)
private data class LyricsUi(val loading: Boolean, val lyrics: Lyrics?)

private fun slideSpec(): AnimatedContentTransitionScope<TrackView>.() -> ContentTransform = {
    (slideInHorizontally(tween(320)) { it / 2 } + fadeIn(tween(320))) togetherWith
        (slideOutHorizontally(tween(320)) { -it / 2 } + fadeOut(tween(200)))
}

private fun fadeSpec(): AnimatedContentTransitionScope<TrackView>.() -> ContentTransform = {
    fadeIn(tween(350)) togetherWith fadeOut(tween(250))
}

@Composable
fun NowPlayingScreen(
    vm: PlayerViewModel,
    settings: AppSettings,
    accent: Color,
    onClose: () -> Unit,
    onSettings: () -> Unit
) {
    val context = LocalContext.current
    val now by vm.now.collectAsStateWithLifecycle()
    val isLocal = now.source == Source.LOCAL
    var showLyrics by rememberSaveable { mutableStateOf(false) }
    LaunchedEffect(isLocal) { if (!isLocal) showLyrics = false }

    // Real waveform of the file (local songs only)
    val peaks by produceState<FloatArray?>(null, now.mediaId, now.source) {
        value = null
        val uri = (now.artwork as? LocalArt)?.uri
        if (now.source == Source.LOCAL && uri != null) value = WaveformRepository.load(context, uri)
    }

    // Time-synced lyrics, only fetched once you open the lyrics view
    val lyricsUi by produceState(LyricsUi(false, null), now.mediaId, showLyrics) {
        if (!showLyrics || !isLocal) {
            value = LyricsUi(false, null)
            return@produceState
        }
        value = LyricsUi(true, null)
        val track = vm.tracks.value.firstOrNull { it.id.toString() == now.mediaId }
        value = LyricsUi(
            false,
            LyricsRepository.load(
                key = now.mediaId,
                artist = track?.artist ?: now.subtitle,
                title = track?.title ?: now.title,
                durationMs = track?.durationMs ?: now.durationMs
            )
        )
    }

    // Vinyl spin
    var angle by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(now.isPlaying, settings.layout) {
        if (now.isPlaying && settings.layout == NpLayout.VINYL) {
            var last = withFrameNanos { it }
            while (true) {
                val t = withFrameNanos { it }
                angle = (angle + (t - last) / 1_000_000_000f * 36f) % 360f
                last = t
            }
        }
    }

    val tv = TrackView(now.mediaId.ifBlank { now.title }, now.title, now.subtitle, now.artwork)
    val spec = if (settings.trackAnim == TrackAnim.SLIDE) slideSpec() else fadeSpec()
    val onVariant = MaterialTheme.colorScheme.onSurfaceVariant
    val progress = if (now.durationMs > 0) (now.positionMs.toFloat() / now.durationMs).coerceIn(0f, 1f) else 0f

    Box(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .pointerInput(Unit) { detectTapGestures { } }
    ) {
        // Blurred cover as background
        if (settings.blurBackground && now.artwork != null) {
            val modern = Build.VERSION.SDK_INT >= 31
            AsyncImage(
                model = now.artwork,
                contentDescription = null,
                contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .then(if (modern) Modifier.blur(80.dp) else Modifier)
                    .alpha(if (modern) 0.55f else 0.18f)
            )
        }
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(Color.Black.copy(alpha = 0.35f), Color.Black.copy(alpha = 0.85f), Color.Black)
                    )
                )
        )

        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 24.dp)
        ) {
            // Top bar
            Row(Modifier.fillMaxWidth().height(56.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onClose) {
                    Icon(Icons.Filled.KeyboardArrowDown, contentDescription = "Close", modifier = Modifier.size(32.dp))
                }
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("NOW PLAYING", style = MaterialTheme.typography.labelSmall, color = onVariant)
                    Text(
                        when (now.source) {
                            Source.LOCAL -> "Music"
                            Source.RADIO -> "Radio"
                            Source.NONE -> ""
                        },
                        style = MaterialTheme.typography.labelLarge
                    )
                }
                if (isLocal) {
                    TextButton(onClick = { showLyrics = !showLyrics }) {
                        Text(
                            "Lyrics",
                            fontWeight = if (showLyrics) FontWeight.SemiBold else FontWeight.Normal,
                            color = if (showLyrics) accent else onVariant
                        )
                    }
                }
                IconButton(onClick = onSettings) {
                    Icon(Icons.Filled.Settings, contentDescription = "Settings")
                }
            }

            // Middle: cover / vinyl / big text / lyrics
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                if (showLyrics) {
                    LyricsView(lyricsUi, now.positionMs, accent) { vm.seekTo(it) }
                } else {
                    AnimatedContent(
                        targetState = tv,
                        transitionSpec = spec,
                        contentKey = { it.id },
                        label = "track-art"
                    ) { t ->
                        when (settings.layout) {
                            NpLayout.CLASSIC -> BoxWithConstraints(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                val side = minOf(maxWidth, maxHeight) - 8.dp
                                Art(t.art, Modifier.size(side), RoundedCornerShape(settings.coverRadius.dp))
                            }
                            NpLayout.VINYL -> BoxWithConstraints(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                val side = minOf(maxWidth, maxHeight) - 8.dp
                                VinylDisc(t.art, { angle }, Modifier.size(side))
                            }
                            NpLayout.MINIMAL -> Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center) {
                                Art(t.art, Modifier.size(64.dp), RoundedCornerShape(minOf(settings.coverRadius.dp, 32.dp)))
                                Spacer(Modifier.height(28.dp))
                                Text(
                                    t.title,
                                    style = MaterialTheme.typography.headlineLarge.copy(fontSize = 34.sp, lineHeight = 40.sp),
                                    maxLines = 4,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(Modifier.height(8.dp))
                                Text(
                                    t.subtitle,
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Normal),
                                    color = onVariant,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }

            // Title + artist (Minimal layout already shows them big)
            if (settings.layout != NpLayout.MINIMAL || showLyrics) {
                AnimatedContent(
                    targetState = tv,
                    transitionSpec = spec,
                    contentKey = { it.id },
                    label = "track-title",
                    modifier = Modifier.padding(top = 8.dp)
                ) { t ->
                    Column(Modifier.fillMaxWidth()) {
                        Text(
                            t.title,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Medium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            t.subtitle,
                            style = MaterialTheme.typography.bodyMedium,
                            color = onVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            // Waveform seek bar (radio is live, so no seeking there)
            if (now.source == Source.RADIO) {
                Row(
                    Modifier.fillMaxWidth().height(56.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(8.dp).clip(CircleShape).background(accent))
                    Spacer(Modifier.size(8.dp))
                    Text("LIVE", style = MaterialTheme.typography.labelLarge)
                }
            } else {
                WaveformSeek(
                    peaks = peaks,
                    progress = progress,
                    accent = accent,
                    seed = now.mediaId.hashCode().toLong(),
                    enabled = now.durationMs > 0,
                    onSeek = { f -> vm.seekTo((f * now.durationMs).toLong()) },
                    modifier = Modifier.fillMaxWidth().height(56.dp)
                )
                Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(formatTime(now.positionMs), style = MaterialTheme.typography.labelMedium, color = onVariant)
                    Text(
                        if (now.durationMs > 0) formatTime(now.durationMs) else "--:--",
                        style = MaterialTheme.typography.labelMedium,
                        color = onVariant
                    )
                }
            }

            // Controls
            Row(
                Modifier.fillMaxWidth().padding(vertical = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { vm.toggleShuffle() }, enabled = isLocal) {
                    Icon(
                        Icons.Filled.Shuffle,
                        contentDescription = "Shuffle",
                        tint = when {
                            !isLocal -> onVariant.copy(alpha = 0.25f)
                            now.shuffle -> accent
                            else -> onVariant
                        }
                    )
                }
                IconButton(onClick = { vm.previous() }) {
                    Icon(Icons.Filled.SkipPrevious, contentDescription = "Previous", modifier = Modifier.size(36.dp))
                }
                FilledIconButton(
                    onClick = { vm.togglePlayPause() },
                    modifier = Modifier.size(72.dp),
                    colors = IconButtonDefaults.filledIconButtonColors(containerColor = accent, contentColor = Color.Black)
                ) {
                    Icon(
                        if (now.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                        contentDescription = if (now.isPlaying) "Pause" else "Play",
                        modifier = Modifier.size(38.dp)
                    )
                }
                IconButton(onClick = { vm.next() }) {
                    Icon(Icons.Filled.SkipNext, contentDescription = "Next", modifier = Modifier.size(36.dp))
                }
                IconButton(onClick = { vm.cycleRepeat() }, enabled = isLocal) {
                    Icon(
                        if (now.repeat == Player.REPEAT_MODE_ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat,
                        contentDescription = "Repeat",
                        tint = when {
                            !isLocal -> onVariant.copy(alpha = 0.25f)
                            now.repeat != Player.REPEAT_MODE_OFF -> accent
                            else -> onVariant
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun VinylDisc(art: Any?, angle: () -> Float, modifier: Modifier) {
    Box(
        modifier
            .graphicsLayer { rotationZ = angle() }
            .clip(CircleShape)
            .background(Color(0xFF0A0A0A)),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val r = size.minDimension / 2f
            for (i in 1..9) {
                drawCircle(
                    color = Color.White.copy(alpha = 0.06f),
                    radius = r * (0.40f + i * 0.06f),
                    style = Stroke(width = 1.dp.toPx())
                )
            }
        }
        Art(art, Modifier.fillMaxSize(0.42f), CircleShape)
        Box(Modifier.size(10.dp).clip(CircleShape).background(Color.Black))
    }
}

@Composable
private fun LyricsView(ui: LyricsUi, positionMs: Long, accent: Color, onSeek: (Long) -> Unit) {
    val lyrics = ui.lyrics
    when {
        ui.loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = accent)
        }
        lyrics == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(
                "No lyrics found for this song",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        else -> {
            val listState = rememberLazyListState()
            val active = if (lyrics.synced) lyrics.lines.indexOfLast { it.timeMs <= positionMs } else -1
            LaunchedEffect(active) {
                if (active >= 0) listState.animateScrollToItem(max(active - 2, 0))
            }
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(vertical = 24.dp)
            ) {
                itemsIndexed(lyrics.lines) { i, line ->
                    val color by animateColorAsState(
                        when {
                            !lyrics.synced -> Color.White.copy(alpha = 0.85f)
                            i == active -> Color.White
                            else -> Color.White.copy(alpha = 0.35f)
                        },
                        label = "lyric"
                    )
                    Text(
                        line.text.ifBlank { "♪" },
                        fontSize = if (lyrics.synced) 26.sp else 18.sp,
                        lineHeight = if (lyrics.synced) 32.sp else 26.sp,
                        fontWeight = if (lyrics.synced) FontWeight.SemiBold else FontWeight.Normal,
                        color = color,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable(enabled = lyrics.synced) { onSeek(line.timeMs) }
                            .padding(vertical = if (lyrics.synced) 8.dp else 2.dp)
                    )
                }
            }
        }
    }
}
