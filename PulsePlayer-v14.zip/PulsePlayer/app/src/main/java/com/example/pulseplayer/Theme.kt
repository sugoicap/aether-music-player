package com.example.pulseplayer

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontVariation
import androidx.compose.ui.text.font.FontWeight

/** Inter (variable font, downloaded at build time into res/font/inter.ttf). */
@OptIn(ExperimentalTextApi::class)
val Inter = FontFamily(
    Font(R.font.inter, FontWeight.Normal, variationSettings = FontVariation.Settings(FontVariation.weight(400))),
    Font(R.font.inter, FontWeight.Medium, variationSettings = FontVariation.Settings(FontVariation.weight(500))),
    Font(R.font.inter, FontWeight.SemiBold, variationSettings = FontVariation.Settings(FontVariation.weight(600))),
    Font(R.font.inter, FontWeight.Bold, variationSettings = FontVariation.Settings(FontVariation.weight(700)))
)

private fun buildTypography(): Typography {
    val b = Typography()
    fun TextStyle.inter(w: FontWeight? = null) =
        copy(fontFamily = Inter, fontWeight = w ?: fontWeight)
    return Typography(
        displayLarge = b.displayLarge.inter(),
        displayMedium = b.displayMedium.inter(),
        displaySmall = b.displaySmall.inter(),
        headlineLarge = b.headlineLarge.inter(FontWeight.SemiBold),
        headlineMedium = b.headlineMedium.inter(FontWeight.SemiBold),
        headlineSmall = b.headlineSmall.inter(FontWeight.SemiBold),
        titleLarge = b.titleLarge.inter(FontWeight.SemiBold),
        titleMedium = b.titleMedium.inter(FontWeight.Medium),
        titleSmall = b.titleSmall.inter(FontWeight.Medium),
        bodyLarge = b.bodyLarge.inter(FontWeight.Normal),
        bodyMedium = b.bodyMedium.inter(FontWeight.Normal),
        bodySmall = b.bodySmall.inter(FontWeight.Normal),
        labelLarge = b.labelLarge.inter(FontWeight.SemiBold),
        labelMedium = b.labelMedium.inter(FontWeight.Medium),
        labelSmall = b.labelSmall.inter(FontWeight.Medium)
    )
}

private val PulseTypography = buildTypography()

@Composable
fun PulseTheme(settings: AppSettings, accent: Color, content: @Composable () -> Unit) {
    val bg = if (settings.oled) Color.Black else Color(0xFF121212)
    val surf = if (settings.oled) Color(0xFF0C0C0E) else Color(0xFF1A1A1C)
    val scheme = remember(settings.oled, accent) { darkColorScheme(
        primary = accent,
        onPrimary = Color.Black,
        secondary = accent,
        onSecondary = Color.Black,
        secondaryContainer = accent.copy(alpha = 0.2f).compositeOver(bg),
        onSecondaryContainer = Color.White,
        background = bg,
        onBackground = Color.White,
        surface = bg,
        onSurface = Color(0xFFF2F2F2),
        surfaceVariant = Color(0xFF1F1F23),
        onSurfaceVariant = Color(0xFFA3A3AB),
        surfaceContainerLowest = bg,
        surfaceContainerLow = surf,
        surfaceContainer = surf,
        surfaceContainerHigh = Color(0xFF18181B),
        surfaceContainerHighest = Color(0xFF212126),
        outline = Color(0xFF3A3A40),
        outlineVariant = Color(0xFF26262B),
        error = Color(0xFFFF6B6B)
    ) }
    MaterialTheme(colorScheme = scheme, typography = PulseTypography, content = content)
}
