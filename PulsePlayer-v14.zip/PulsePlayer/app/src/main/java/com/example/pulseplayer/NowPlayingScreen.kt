package com.example.pulseplayer

import android.os.Build
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.ContentTransform
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.Player
import coil.compose.AsyncImage
import coil.request.ImageRequest
import kotlin.math.max

private data class TrackView(val id: String, val title: String, val subtitle: String, val album: String, val art: Any?)

private fun slideSpec(): AnimatedContentTransitionScope<TrackView>.() -> ContentTransform = {
    (slideInHorizontally(tween(320)) { it / 2 } + fadeIn(tween(320))) togetherWith
        (slideOutHorizontally(tween(320)) { -it / 2 } + fadeOut(tween(200)))
}

private fun fadeSpec(): AnimatedContentTransitionScope<TrackView>.() -> ContentTransform = {
    fadeIn(tween(350)) togetherWith fadeOut(tween(250))
}

@Composable
fun NowPlayingScreen(
    vm: PlayerViewModel,
    settings: AppSettings,
    accent: Color,
    onClose: () -> Unit,
    onSettings: () -> Unit
) {
    val context = LocalContext.current
    val S = LocalStr.current
    val now by vm.now.collectAsStateWithLifecycle()
    val isLocal = now.source == Source.LOCAL

    // Real waveform of the file (local songs only)
    val peaks by produceState<FloatArray?>(null, now.mediaId, now.source) {
        value = null
        // Let the track-change animation finish (and skip quick taps) before decoding the file
        kotlinx.coroutines.delay(500)
        val uri = (now.artwork as? LocalArt)?.uri
        if (now.source == Source.LOCAL && uri != null) value = WaveformRepository.load(context, uri)
    }

    // Vinyl spin
    var angle by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(now.isPlaying, settings.layout) {
        if (now.isPlaying && settings.layout == NpLayout.VINYL) {
            var last = withFrameNanos { it }
            while (true) {
                val t = withFrameNanos { it }
                angle = (angle + (t - last) / 1_000_000_000f * 36f) % 360f
                last = t
            }
        }
    }

    val tv = TrackView(now.mediaId.ifBlank { now.title }, now.title, now.subtitle, now.album, now.artwork)
    val spec = if (settings.trackAnim == TrackAnim.SLIDE) slideSpec() else fadeSpec()
    val onVariant = MaterialTheme.colorScheme.onSurfaceVariant

    CompositionLocalProvider(LocalContentColor provides MaterialTheme.colorScheme.onBackground) {
    Box(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .pointerInput(Unit) { detectTapGestures { } }
    ) {
        // Blurred cover as background
        if (settings.blurBackground && now.artwork != null) {
            val modern = Build.VERSION.SDK_INT >= 31
            AsyncImage(
                model = remember(now.artwork) {
                    ImageRequest.Builder(context).data(now.artwork).size(256).build()
                },
                contentDescription = null,
                contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .then(if (modern) Modifier.blur(28.dp) else Modifier)
                    .alpha(if (modern) 0.55f else 0.18f)
            )
        }
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(Color.Black.copy(alpha = 0.35f), Color.Black.copy(alpha = 0.85f), Color.Black)
                    )
                )
        )

        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 24.dp)
        ) {
            // Top bar
            Row(Modifier.fillMaxWidth().height(56.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onClose) {
                    Icon(Icons.Filled.KeyboardArrowDown, contentDescription = S.close, modifier = Modifier.size(32.dp))
                }
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(S.nowPlaying, style = MaterialTheme.typography.labelSmall, color = onVariant)
                    Text(
                        when (now.source) {
                            Source.LOCAL -> S.tabLibrary
                            Source.RADIO -> S.tabRadio
                            Source.NONE -> ""
                        },
                        style = MaterialTheme.typography.labelLarge
                    )
                }
                IconButton(onClick = onSettings) {
                    Icon(Icons.Filled.Settings, contentDescription = S.settings)
                }
            }

            // Middle: cover / vinyl / big text
            Box(
                Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                run {
                    AnimatedContent(
                        targetState = tv,
                        transitionSpec = spec,
                        contentKey = { it.id },
                        label = "track-art"
                    ) { t ->
                        when (settings.layout) {
                            NpLayout.CLASSIC -> BoxWithConstraints(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                val side = minOf(maxWidth, maxHeight) - 8.dp
                                Art(t.art, Modifier.size(side), RoundedCornerShape(settings.coverRadius.dp))
                            }
                            NpLayout.VINYL -> BoxWithConstraints(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                val side = minOf(maxWidth, maxHeight) - 8.dp
                                VinylDisc(t.art, { angle }, Modifier.size(side))
                            }
                            NpLayout.MINIMAL -> Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center) {
                                Art(t.art, Modifier.size(64.dp), RoundedCornerShape(minOf(settings.coverRadius.dp, 32.dp)))
                                Spacer(Modifier.height(28.dp))
                                Text(
                                    t.title,
                                    style = MaterialTheme.typography.headlineLarge.copy(fontSize = 34.sp, lineHeight = 40.sp),
                                    maxLines = 4,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(Modifier.height(8.dp))
                                Text(
                                    t.subtitle,
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Normal),
                                    color = onVariant,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                                if (t.album.isNotBlank()) {
                                    Text(
                                        t.album,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = onVariant.copy(alpha = 0.7f),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Title + artist (Minimal layout already shows them big)
            if (settings.layout != NpLayout.MINIMAL) {
                AnimatedContent(
                    targetState = tv,
                    transitionSpec = spec,
                    contentKey = { it.id },
                    label = "track-title",
                    modifier = Modifier.padding(top = 8.dp)
                ) { t ->
                    Column(Modifier.fillMaxWidth()) {
                        Text(
                            t.title,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Medium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        if (t.subtitle.isNotBlank()) {
                            Text(
                                t.subtitle,
                                style = MaterialTheme.typography.bodyLarge,
                                color = onVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        if (t.album.isNotBlank()) {
                            Text(
                                t.album,
                                style = MaterialTheme.typography.bodyMedium,
                                color = onVariant.copy(alpha = 0.7f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            // Waveform seek bar (radio is live, so no seeking there)
            if (now.source == Source.RADIO) {
                Row(
                    Modifier.fillMaxWidth().height(56.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(8.dp).clip(CircleShape).background(accent))
                    Spacer(Modifier.size(8.dp))
                    Text(S.live, style = MaterialTheme.typography.labelLarge)
                }
            } else {
                ProgressSection(vm, peaks, accent, now.mediaId)
            }

            // Controls
            Row(
                Modifier.fillMaxWidth().padding(vertical = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { vm.toggleShuffle() }, enabled = isLocal) {
                    Icon(
                        Icons.Filled.Shuffle,
                        contentDescription = S.shuffle,
                        tint = when {
                            !isLocal -> onVariant.copy(alpha = 0.25f)
                            now.shuffle -> accent
                            else -> onVariant
                        }
                    )
                }
                IconButton(onClick = { vm.previous() }) {
                    Icon(Icons.Filled.SkipPrevious, contentDescription = S.previous, modifier = Modifier.size(36.dp))
                }
                FilledIconButton(
                    onClick = { vm.togglePlayPause() },
                    modifier = Modifier.size(72.dp),
                    colors = IconButtonDefaults.filledIconButtonColors(containerColor = accent, contentColor = Color.Black)
                ) {
                    Icon(
                        if (now.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                        contentDescription = if (now.isPlaying) S.pause else S.play,
                        modifier = Modifier.size(38.dp)
                    )
                }
                IconButton(onClick = { vm.next() }) {
                    Icon(Icons.Filled.SkipNext, contentDescription = S.next, modifier = Modifier.size(36.dp))
                }
                IconButton(onClick = { vm.cycleRepeat() }, enabled = isLocal) {
                    Icon(
                        if (now.repeat == Player.REPEAT_MODE_ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat,
                        contentDescription = S.repeat,
                        tint = when {
                            !isLocal -> onVariant.copy(alpha = 0.25f)
                            now.repeat != Player.REPEAT_MODE_OFF -> accent
                            else -> onVariant
                        }
                    )
                }
            }
        }
    }
    }
}

/** Collects the fast-changing progress here so the rest of the screen doesn't recompose. */
@Composable
private fun ProgressSection(vm: PlayerViewModel, peaks: FloatArray?, accent: Color, mediaId: String) {
    val p by vm.progress.collectAsStateWithLifecycle()
    val onVariant = MaterialTheme.colorScheme.onSurfaceVariant
    val fraction = if (p.durationMs > 0) (p.positionMs.toFloat() / p.durationMs).coerceIn(0f, 1f) else 0f
    WaveformSeek(
        peaks = peaks,
        progress = fraction,
        accent = accent,
        seed = mediaId.hashCode().toLong(),
        enabled = p.durationMs > 0,
        onSeek = { f -> vm.seekTo((f * p.durationMs).toLong()) },
        modifier = Modifier.fillMaxWidth().height(56.dp)
    )
    Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(formatTime(p.positionMs), style = MaterialTheme.typography.labelMedium, color = onVariant)
        Text(
            if (p.durationMs > 0) formatTime(p.durationMs) else "--:--",
            style = MaterialTheme.typography.labelMedium,
            color = onVariant
        )
    }
}

@Composable
private fun VinylDisc(art: Any?, angle: () -> Float, modifier: Modifier) {
    Box(
        modifier
            .graphicsLayer { rotationZ = angle() }
            .clip(CircleShape)
            .background(Color(0xFF0A0A0A)),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val r = size.minDimension / 2f
            for (i in 1..9) {
                drawCircle(
                    color = Color.White.copy(alpha = 0.06f),
                    radius = r * (0.40f + i * 0.06f),
                    style = Stroke(width = 1.dp.toPx())
                )
            }
        }
        Art(art, Modifier.fillMaxSize(0.42f), CircleShape)
        Box(Modifier.size(10.dp).clip(CircleShape).background(Color.Black))
    }
}
