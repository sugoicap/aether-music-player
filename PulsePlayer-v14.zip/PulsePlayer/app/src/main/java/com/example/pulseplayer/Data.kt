package com.example.pulseplayer

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

internal fun httpGet(url: String, timeoutMs: Int = 10_000): String {
    val conn = URL(url).openConnection() as HttpURLConnection
    conn.connectTimeout = timeoutMs
    conn.readTimeout = timeoutMs
    conn.setRequestProperty("User-Agent", "Aether/1.0")
    try {
        if (conn.responseCode !in 200..299) throw IOException("HTTP ${conn.responseCode}")
        return conn.inputStream.bufferedReader().use { it.readText() }
    } finally {
        conn.disconnect()
    }
}

private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

/** Music stored on the phone, read from MediaStore. */
object LocalMusicRepository {
    private val artBase: Uri = Uri.parse("content://media/external/audio/albumart")

    suspend fun load(context: Context, unknownArtist: String): List<Track> = withContext(Dispatchers.IO) {
        val out = ArrayList<Track>()
        val collection: Uri = if (Build.VERSION.SDK_INT >= 29) {
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        }
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.TRACK
        ) + (if (Build.VERSION.SDK_INT >= 30) arrayOf(MediaStore.Audio.Media.BITRATE) else emptyArray<String>()) +
            (if (Build.VERSION.SDK_INT >= 29) arrayOf(MediaStore.Audio.Media.RELATIVE_PATH) else arrayOf(MediaStore.Audio.Media.DATA))
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= 30000"
        val order = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"

        context.contentResolver.query(collection, projection, selection, null, order)?.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val iTitle = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val iArtist = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val iAlbum = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val iDur = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val iAlbumId = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            val iName = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
            val iBitrate = if (Build.VERSION.SDK_INT >= 30) c.getColumnIndex(MediaStore.Audio.Media.BITRATE) else -1
            val iTrack = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TRACK)
            val iPath = if (Build.VERSION.SDK_INT >= 29) {
                c.getColumnIndexOrThrow(MediaStore.Audio.Media.RELATIVE_PATH)
            } else {
                c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
            }
            while (c.moveToNext()) {
                val id = c.getLong(iId)
                val artist = c.getString(iArtist)?.takeUnless { it == "<unknown>" } ?: unknownArtist
                val rawPath = c.getString(iPath).orEmpty()
                val folderPath = if (Build.VERSION.SDK_INT >= 29) {
                    rawPath.trim('/')
                } else {
                    rawPath.substringBeforeLast('/', "").trim('/')
                }
                out += Track(
                    id = id,
                    title = c.getString(iTitle) ?: "Untitled",
                    artist = artist,
                    album = c.getString(iAlbum) ?: "",
                    durationMs = c.getLong(iDur),
                    uri = ContentUris.withAppendedId(collection, id),
                    artwork = ContentUris.withAppendedId(artBase, c.getLong(iAlbumId)),
                    format = (c.getString(iName) ?: "").substringAfterLast('.', "").uppercase(),
                    bitrateKbps = if (iBitrate >= 0) (c.getInt(iBitrate) / 1000) else 0,
                    albumId = c.getLong(iAlbumId),
                    trackNo = c.getInt(iTrack),
                    folderPath = folderPath,
                    folder = folderPath.substringAfterLast('/').ifBlank { "Storage" }
                )
            }
        }
        out
    }
}

/** Online radio via the free community Radio Browser directory (radio-browser.info). */
object RadioRepository {
    private val hosts = listOf(
        "https://de1.api.radio-browser.info",
        "https://nl1.api.radio-browser.info",
        "https://at1.api.radio-browser.info"
    )

    suspend fun search(name: String, tag: String?, limit: Int = 60): List<Station> =
        withContext(Dispatchers.IO) {
            val path = if (name.isBlank() && tag == null) {
                "/json/stations/topclick/$limit?hidebroken=true"
            } else {
                buildString {
                    append("/json/stations/search?limit=$limit&hidebroken=true&order=clickcount&reverse=true")
                    if (name.isNotBlank()) append("&name=").append(enc(name))
                    if (tag != null) append("&tag=").append(enc(tag))
                }
            }
            parse(getFromAnyHost(path))
        }

    suspend fun countries(): List<Facet> = withContext(Dispatchers.IO) {
        facets("/json/countries?hidebroken=true&order=stationcount&reverse=true")
    }

    suspend fun languages(): List<Facet> = withContext(Dispatchers.IO) {
        facets("/json/languages?hidebroken=true&order=stationcount&reverse=true")
    }

    /** Stations of one country or language, optionally filtered by [name]. */
    suspend fun byFacet(kind: FacetKind, value: String, name: String, limit: Int = 100): List<Station> =
        withContext(Dispatchers.IO) {
            val key = if (kind == FacetKind.COUNTRY) "country" else "language"
            var path = "/json/stations/search?limit=$limit&hidebroken=true&order=clickcount&reverse=true" +
                "&$key=${enc(value)}&${key}Exact=true"
            if (name.isNotBlank()) path += "&name=${enc(name)}"
            parse(getFromAnyHost(path))
        }

    private fun facets(path: String): List<Facet> {
        val arr = JSONArray(getFromAnyHost(path))
        val out = ArrayList<Facet>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val name = o.optString("name").trim()
            val count = o.optInt("stationcount", 0)
            if (name.isNotBlank() && count > 0) out += Facet(name, count)
        }
        return out
    }

    /** Tells the directory a station was played (keeps its popularity ranking honest). */
    suspend fun countClick(id: String) = withContext(Dispatchers.IO) {
        try {
            httpGet("${hosts.first()}/json/url/$id", 5_000)
        } catch (_: Exception) {
        }
    }

    private fun getFromAnyHost(path: String): String {
        var last: Exception? = null
        for (host in hosts) {
            try {
                return httpGet(host + path)
            } catch (e: Exception) {
                last = e
            }
        }
        throw last ?: IOException("No radio server reachable")
    }

    private fun parse(body: String): List<Station> {
        val arr = JSONArray(body)
        val out = ArrayList<Station>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val url = o.optString("url_resolved").ifBlank { o.optString("url") }
            val name = o.optString("name").trim()
            if (url.isBlank() || name.isBlank()) continue
            out += Station(
                id = o.optString("stationuuid"),
                name = name,
                url = url,
                country = o.optString("country"),
                tags = o.optString("tags"),
                favicon = o.optString("favicon"),
                bitrate = o.optInt("bitrate", 0)
            )
        }
        return out.distinctBy { it.name.lowercase() }
    }
}

/** Saves favourite stations on the device. */
class Store(context: Context) {
    private val prefs = context.getSharedPreferences("pulse_store", Context.MODE_PRIVATE)

    fun loadFavorites(): List<Station> = readArray("fav") {
        Station(
            id = it.getString("id"),
            name = it.optString("name"),
            url = it.optString("url"),
            country = it.optString("country"),
            tags = it.optString("tags"),
            favicon = it.optString("favicon"),
            bitrate = it.optInt("bitrate", 0)
        )
    }

    fun saveFavorites(items: List<Station>) = writeArray("fav", items) {
        JSONObject()
            .put("id", it.id).put("name", it.name).put("url", it.url)
            .put("country", it.country).put("tags", it.tags)
            .put("favicon", it.favicon).put("bitrate", it.bitrate)
    }

    private fun <T> readArray(key: String, map: (JSONObject) -> T): List<T> = try {
        val arr = JSONArray(prefs.getString(key, "[]"))
        List(arr.length()) { map(arr.getJSONObject(it)) }
    } catch (_: Exception) {
        emptyList()
    }

    private fun <T> writeArray(key: String, items: List<T>, map: (T) -> JSONObject) {
        val arr = JSONArray()
        items.forEach { arr.put(map(it)) }
        prefs.edit().putString(key, arr.toString()).apply()
    }
}

/**
 * Reads the song that an Icecast/Shoutcast radio stream is playing right now ("StreamTitle"),
 * by opening the stream with the ICY metadata header and parsing the first metadata block.
 */
object IcyReader {
    suspend fun currentTitle(url: String): String? = withContext(Dispatchers.IO) {
        var conn: HttpURLConnection? = null
        try {
            conn = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 6_000
                readTimeout = 8_000
                instanceFollowRedirects = true
                setRequestProperty("Icy-MetaData", "1")
                setRequestProperty("User-Agent", "Aether/1.0")
            }
            val interval = conn.getHeaderField("icy-metaint")?.trim()?.toIntOrNull() ?: return@withContext null
            if (interval <= 0) return@withContext null
            val input = conn.inputStream
            val skipBuf = ByteArray(4096)
            repeat(4) { // the metadata block can be empty; try the next one a few times
                var left = interval
                while (left > 0) {
                    val n = input.read(skipBuf, 0, minOf(left, skipBuf.size))
                    if (n < 0) return@withContext null
                    left -= n
                }
                val len = input.read()
                if (len < 0) return@withContext null
                if (len > 0) {
                    val buf = ByteArray(len * 16)
                    var off = 0
                    while (off < buf.size) {
                        val n = input.read(buf, off, buf.size - off)
                        if (n < 0) break
                        off += n
                    }
                    var text = String(buf, 0, off, Charsets.UTF_8)
                    if (text.contains('\uFFFD')) text = String(buf, 0, off, Charsets.ISO_8859_1)
                    val title = Regex("StreamTitle='(.*?)';", RegexOption.DOT_MATCHES_ALL)
                        .find(text)?.groupValues?.get(1)?.trim()
                    if (!title.isNullOrBlank()) return@withContext title
                }
            }
            null
        } catch (e: Exception) {
            null
        } finally {
            conn?.disconnect()
        }
    }
}
