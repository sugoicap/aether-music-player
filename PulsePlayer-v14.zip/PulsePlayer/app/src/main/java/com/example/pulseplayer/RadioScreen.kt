package com.example.pulseplayer

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Radio
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle

private enum class RadioView {
    FAVORITES, COUNTRIES, LANGUAGES, ALL;

    fun label(s: Str) = when (this) {
        FAVORITES -> s.rFavorites
        COUNTRIES -> s.rCountries
        LANGUAGES -> s.rLanguages
        ALL -> s.rAll
    }
}

@Composable
fun RadioScreen(vm: PlayerViewModel) {
    val S = LocalStr.current
    val favorites by vm.favorites.collectAsStateWithLifecycle()
    val stations by vm.stations.collectAsStateWithLifecycle()
    val countries by vm.countries.collectAsStateWithLifecycle()
    val languages by vm.languages.collectAsStateWithLifecycle()
    val facetStations by vm.facetStations.collectAsStateWithLifecycle()
    val loading by vm.radioLoading.collectAsStateWithLifecycle()
    val error by vm.radioError.collectAsStateWithLifecycle()
    val currentId by vm.currentStationId.collectAsStateWithLifecycle()
    val searchOpen by vm.radioSearchOpen.collectAsStateWithLifecycle()
    val query by vm.radioQuery.collectAsStateWithLifecycle()

    var viewIdx by rememberSaveable { mutableStateOf(RadioView.FAVORITES.ordinal) }
    var facetName by rememberSaveable { mutableStateOf<String?>(null) }
    val view = RadioView.entries[viewIdx]
    val q = query.trim()
    val focus = remember { FocusRequester() }
    LaunchedEffect(searchOpen) { if (searchOpen) focus.requestFocus() }

    val facetKind = if (view == RadioView.COUNTRIES) FacetKind.COUNTRY else FacetKind.LANGUAGE
    val inFacet = facetName != null && (view == RadioView.COUNTRIES || view == RadioView.LANGUAGES)
    BackHandler(enabled = inFacet) {
        facetName = null
        vm.leaveFacet()
    }

    // Load what the current sub menu needs (nothing is fetched until it is opened)
    LaunchedEffect(view, facetName, q) {
        when (view) {
            RadioView.FAVORITES -> {}
            RadioView.COUNTRIES ->
                if (facetName == null) vm.loadCountries() else vm.loadFacetStations(FacetKind.COUNTRY, facetName!!, q)
            RadioView.LANGUAGES ->
                if (facetName == null) vm.loadLanguages() else vm.loadFacetStations(FacetKind.LANGUAGE, facetName!!, q)
            RadioView.ALL -> vm.searchRadio(q, null)
        }
    }

    fun retry() {
        when (view) {
            RadioView.FAVORITES -> {}
            RadioView.COUNTRIES ->
                if (facetName == null) vm.loadCountries(true) else vm.loadFacetStations(FacetKind.COUNTRY, facetName!!, q, true)
            RadioView.LANGUAGES ->
                if (facetName == null) vm.loadLanguages(true) else vm.loadFacetStations(FacetKind.LANGUAGE, facetName!!, q, true)
            RadioView.ALL -> vm.searchRadio(q, null, true)
        }
    }

    Column(Modifier.fillMaxSize()) {
        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(RadioView.entries.toList()) { v ->
                TextTab(v.label(S).uppercase(), v == view) {
                    if (v != view) {
                        viewIdx = v.ordinal
                        facetName = null
                        vm.leaveFacet()
                    }
                }
            }
        }

        if (searchOpen) {
            OutlinedTextField(
                value = query,
                onValueChange = { vm.radioQuery.value = it },
                placeholder = {
                    Text(
                        when (view) {
                            RadioView.FAVORITES -> S.rSearchFavorites
                            RadioView.COUNTRIES -> if (facetName == null) S.rSearchCountry else S.rSearchStation
                            RadioView.LANGUAGES -> if (facetName == null) S.rSearchLanguage else S.rSearchStation
                            RadioView.ALL -> S.rSearchStation
                        }
                    )
                },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
                    .focusRequester(focus)
            )
        }

        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())

        if (inFacet) {
            Row(Modifier.fillMaxWidth().padding(end = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = {
                    facetName = null
                    vm.leaveFacet()
                }) { Icon(Icons.Filled.ArrowBack, contentDescription = S.back) }
                Text(
                    facetName.orEmpty().replaceFirstChar { it.uppercase() },
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        val err = error
        if (view != RadioView.FAVORITES && err != null) {
            Column(Modifier.padding(24.dp)) {
                Text(err, color = MaterialTheme.colorScheme.error)
                TextButton(onClick = { retry() }) { Text(S.retry) }
            }
            return@Column
        }

        when {
            view == RadioView.FAVORITES -> {
                val list = remember(favorites, q) {
                    if (q.isEmpty()) favorites else favorites.filter {
                        it.name.contains(q, true) || it.country.contains(q, true) || it.tags.contains(q, true)
                    }
                }
                if (list.isEmpty()) {
                    Hint(
                        if (favorites.isEmpty()) S.emptyFavorites
                        else S.noResults
                    )
                } else {
                    StationList(vm, list, favorites, currentId)
                }
            }

            inFacet -> {
                if (facetStations.isEmpty() && !loading) Hint(S.noResults)
                else StationList(vm, facetStations, favorites, currentId)
            }

            view == RadioView.COUNTRIES || view == RadioView.LANGUAGES -> {
                val src = if (view == RadioView.COUNTRIES) countries else languages
                val list = remember(src, q) {
                    if (q.isEmpty()) src else src.filter { it.name.contains(q, true) }
                }
                if (list.isEmpty() && !loading) {
                    Hint(S.noResults)
                } else {
                    LazyColumn(Modifier.fillMaxSize()) {
                        items(list, key = { it.name }) { f ->
                            ListItem(
                                modifier = Modifier.clickable { facetName = f.name },
                                colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                                headlineContent = { Text(f.label, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                trailingContent = {
                                    Text(
                                        "${f.count}",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            )
                        }
                    }
                }
            }

            else -> {
                if (stations.isEmpty() && !loading) Hint(S.noResults)
                else StationList(vm, stations, favorites, currentId)
            }
        }
    }
}

@Composable
private fun Hint(text: String) {
    Text(text, modifier = Modifier.padding(24.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
private fun StationList(
    vm: PlayerViewModel,
    list: List<Station>,
    favorites: List<Station>,
    currentId: String
) {
    val S = LocalStr.current
    LazyColumn(Modifier.fillMaxSize()) {
        itemsIndexed(list, key = { _, s -> s.id }) { index, station ->
            val current = currentId == station.id
            val isFavorite = favorites.any { it.id == station.id }
            ListItem(
                modifier = Modifier.clickable { vm.playStation(list, index) },
                colors = ListItemDefaults.colors(
                    containerColor = if (current) MaterialTheme.colorScheme.secondaryContainer else Color.Transparent
                ),
                leadingContent = { Artwork(station.favicon, 48.dp, Icons.Filled.Radio) },
                headlineContent = { Text(station.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                supportingContent = { Text(station.subtitle, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                trailingContent = {
                    IconButton(onClick = { vm.toggleFavorite(station) }) {
                        Icon(
                            if (isFavorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                            contentDescription = if (isFavorite) S.removeFavorite else S.addFavorite,
                            tint = if (isFavorite) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            )
        }
    }
}
