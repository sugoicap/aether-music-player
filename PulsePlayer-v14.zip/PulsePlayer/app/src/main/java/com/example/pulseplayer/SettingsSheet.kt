@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.pulseplayer

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

@Composable
fun SettingsSheet(s: AppSettings, onChange: (AppSettings) -> Unit, onDismiss: () -> Unit) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
    ) {
        Column(
            Modifier
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp)
        ) {
            val S = LocalStr.current
            val context = LocalContext.current
            val version = remember {
                try {
                    context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: ""
                } catch (e: Exception) {
                    ""
                }
            }
            Section(S.sLanguage)
            ChipRow(
                listOf("Magyar" to Lang.HU, "English" to Lang.EN),
                s.lang
            ) { onChange(s.copy(lang = it)) }

            Section(S.sTheme)
            SwitchRow(S.sOled, s.oled) { onChange(s.copy(oled = it)) }
            Label(S.sAccent)
            ChipRow(
                listOf(S.sAlbumArt to AccentMode.ALBUM, S.sCustom to AccentMode.MANUAL),
                s.accentMode
            ) { onChange(s.copy(accentMode = it)) }
            if (s.accentMode == AccentMode.MANUAL) {
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    AccentPresets.forEach { c ->
                        Spacer(
                            Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(Color(c))
                                .border(
                                    2.dp,
                                    if (c == s.manualAccent) Color.White else Color.Transparent,
                                    CircleShape
                                )
                                .clickable { onChange(s.copy(manualAccent = c)) }
                        )
                    }
                }
            }

            Section(S.sNowPlaying)
            Label(S.sLayout)
            ChipRow(
                listOf(S.sClassic to NpLayout.CLASSIC, S.sMinimal to NpLayout.MINIMAL, S.sVinyl to NpLayout.VINYL),
                s.layout
            ) { onChange(s.copy(layout = it)) }
            var radius by remember(s.coverRadius) { mutableFloatStateOf(s.coverRadius.toFloat()) }
            Label(S.sRadius(radius.roundToInt()))
            Slider(
                value = radius,
                onValueChange = { radius = it },
                onValueChangeFinished = { onChange(s.copy(coverRadius = radius.roundToInt())) },
                valueRange = 0f..48f
            )
            SwitchRow(S.sBlur, s.blurBackground) { onChange(s.copy(blurBackground = it)) }
            Label(S.sAnim)
            ChipRow(
                listOf(S.sSlide to TrackAnim.SLIDE, S.sFade to TrackAnim.FADE),
                s.trackAnim
            ) { onChange(s.copy(trackAnim = it)) }

            Section(S.sLibrary)
            Label(S.sView)
            ChipRow(
                listOf(S.sGrid to ListMode.GRID, S.sCompact to ListMode.COMPACT, S.sDetailed to ListMode.DETAILED),
                s.listMode
            ) { onChange(s.copy(listMode = it)) }
            if (s.listMode == ListMode.GRID) {
                Label(S.sColumns)
                ChipRow(
                    listOf("2" to 2, "3" to 3, "4" to 4),
                    s.gridColumns
                ) { onChange(s.copy(gridColumns = it)) }
            }

            Section(S.sAbout)
            Text("Aether", style = MaterialTheme.typography.titleMedium)
            Text(
                S.aboutApp,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 2.dp, bottom = 8.dp)
            )
            AboutRow(S.aboutVersion, version)
            AboutRow(S.aboutCreator, APP_AUTHOR)
        }
    }
}

@Composable
private fun AboutRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
        Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun Section(title: String) {
    Text(
        title.uppercase(),
        style = MaterialTheme.typography.labelMedium,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 24.dp, bottom = 8.dp)
    )
}

@Composable
private fun Label(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(top = 12.dp, bottom = 6.dp)
    )
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(top = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChecked)
    }
}

@Composable
private fun <T> ChipRow(options: List<Pair<String, T>>, selected: T, onSelect: (T) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { (label, value) ->
            FilterChip(
                selected = value == selected,
                onClick = { onSelect(value) },
                label = {
                    Text(
                        label,
                        fontWeight = if (value == selected) FontWeight.SemiBold else FontWeight.Normal
                    )
                }
            )
        }
    }
}
