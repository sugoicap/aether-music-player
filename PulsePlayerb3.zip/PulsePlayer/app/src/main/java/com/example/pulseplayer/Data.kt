package com.example.pulseplayer

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

internal fun httpGet(url: String, timeoutMs: Int = 10_000): String {
    val conn = URL(url).openConnection() as HttpURLConnection
    conn.connectTimeout = timeoutMs
    conn.readTimeout = timeoutMs
    conn.setRequestProperty("User-Agent", "PulsePlayer/1.0")
    try {
        if (conn.responseCode !in 200..299) throw IOException("HTTP ${conn.responseCode}")
        return conn.inputStream.bufferedReader().use { it.readText() }
    } finally {
        conn.disconnect()
    }
}

private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

/** Music stored on the phone, read from MediaStore. */
object LocalMusicRepository {
    private val artBase: Uri = Uri.parse("content://media/external/audio/albumart")

    suspend fun load(context: Context): List<Track> = withContext(Dispatchers.IO) {
        val out = ArrayList<Track>()
        val collection: Uri = if (Build.VERSION.SDK_INT >= 29) {
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        }
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DISPLAY_NAME
        ) + (if (Build.VERSION.SDK_INT >= 30) arrayOf(MediaStore.Audio.Media.BITRATE) else emptyArray<String>())
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= 30000"
        val order = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"

        context.contentResolver.query(collection, projection, selection, null, order)?.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val iTitle = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val iArtist = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val iAlbum = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val iDur = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val iAlbumId = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            val iName = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
            val iBitrate = if (Build.VERSION.SDK_INT >= 30) c.getColumnIndex(MediaStore.Audio.Media.BITRATE) else -1
            while (c.moveToNext()) {
                val id = c.getLong(iId)
                val artist = c.getString(iArtist)?.takeUnless { it == "<unknown>" } ?: "Unknown artist"
                out += Track(
                    id = id,
                    title = c.getString(iTitle) ?: "Untitled",
                    artist = artist,
                    album = c.getString(iAlbum) ?: "",
                    durationMs = c.getLong(iDur),
                    uri = ContentUris.withAppendedId(collection, id),
                    artwork = ContentUris.withAppendedId(artBase, c.getLong(iAlbumId)),
                    format = (c.getString(iName) ?: "").substringAfterLast('.', "").uppercase(),
                    bitrateKbps = if (iBitrate >= 0) (c.getInt(iBitrate) / 1000) else 0
                )
            }
        }
        out
    }
}

/** Online radio via the free community Radio Browser directory (radio-browser.info). */
object RadioRepository {
    private val hosts = listOf(
        "https://de1.api.radio-browser.info",
        "https://nl1.api.radio-browser.info",
        "https://at1.api.radio-browser.info"
    )

    suspend fun search(name: String, tag: String?, limit: Int = 60): List<Station> =
        withContext(Dispatchers.IO) {
            val path = if (name.isBlank() && tag == null) {
                "/json/stations/topclick/$limit?hidebroken=true"
            } else {
                buildString {
                    append("/json/stations/search?limit=$limit&hidebroken=true&order=clickcount&reverse=true")
                    if (name.isNotBlank()) append("&name=").append(enc(name))
                    if (tag != null) append("&tag=").append(enc(tag))
                }
            }
            parse(getFromAnyHost(path))
        }

    /** Tells the directory a station was played (keeps its popularity ranking honest). */
    suspend fun countClick(id: String) = withContext(Dispatchers.IO) {
        try {
            httpGet("${hosts.first()}/json/url/$id", 5_000)
        } catch (_: Exception) {
        }
    }

    private fun getFromAnyHost(path: String): String {
        var last: Exception? = null
        for (host in hosts) {
            try {
                return httpGet(host + path)
            } catch (e: Exception) {
                last = e
            }
        }
        throw last ?: IOException("No radio server reachable")
    }

    private fun parse(body: String): List<Station> {
        val arr = JSONArray(body)
        val out = ArrayList<Station>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val url = o.optString("url_resolved").ifBlank { o.optString("url") }
            val name = o.optString("name").trim()
            if (url.isBlank() || name.isBlank()) continue
            out += Station(
                id = o.optString("stationuuid"),
                name = name,
                url = url,
                country = o.optString("country"),
                tags = o.optString("tags"),
                favicon = o.optString("favicon"),
                bitrate = o.optInt("bitrate", 0)
            )
        }
        return out.distinctBy { it.name.lowercase() }
    }
}

/** Helpers for YouTube links. Playback itself uses the official embedded player. */
object YouTubeRepository {
    private val linkRegex = Regex("(?:youtu\\.be/|[?&]v=|/embed/|/shorts/|/live/)([A-Za-z0-9_-]{11})")
    private val bareId = Regex("^[A-Za-z0-9_-]{11}$")

    fun extractVideoId(input: String): String? {
        val text = input.trim()
        return linkRegex.find(text)?.groupValues?.get(1) ?: if (bareId.matches(text)) text else null
    }

    private fun unescape(s: String): String =
        android.text.Html.fromHtml(s, android.text.Html.FROM_HTML_MODE_LEGACY).toString()

    private val isoDuration = Regex("PT(?:(\\d+)H)?(?:(\\d+)M)?(?:(\\d+)S)?")

    private fun isoToMs(iso: String): Long {
        val m = isoDuration.matchEntire(iso) ?: return 0L
        val h = m.groupValues[1].toLongOrNull() ?: 0L
        val min = m.groupValues[2].toLongOrNull() ?: 0L
        val s = m.groupValues[3].toLongOrNull() ?: 0L
        return (h * 3600 + min * 60 + s) * 1000
    }

    private fun fetchDurations(apiKey: String, ids: List<String>): Map<String, Long> {
        if (ids.isEmpty()) return emptyMap()
        val url = "https://www.googleapis.com/youtube/v3/videos?part=contentDetails" +
            "&id=${enc(ids.joinToString(","))}&key=${enc(apiKey)}"
        val arr = JSONObject(httpGet(url)).optJSONArray("items") ?: return emptyMap()
        val out = HashMap<String, Long>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val d = o.optJSONObject("contentDetails")?.optString("duration").orEmpty()
            out[o.optString("id")] = isoToMs(d)
        }
        return out
    }

    /** Music videos matching [query] (YouTube Data API v3). Only videos that may be embedded. */
    suspend fun search(apiKey: String, query: String, pageToken: String?): YtPage =
        withContext(Dispatchers.IO) {
            var url = "https://www.googleapis.com/youtube/v3/search?part=snippet&type=video" +
                "&videoCategoryId=10&videoEmbeddable=true&maxResults=25" +
                "&q=${enc(query)}&key=${enc(apiKey)}"
            if (pageToken != null) url += "&pageToken=${enc(pageToken)}"
            val root = JSONObject(httpGet(url))
            val arr = root.optJSONArray("items") ?: JSONArray()
            val base = ArrayList<YtItem>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val id = o.optJSONObject("id")?.optString("videoId").orEmpty()
                val sn = o.optJSONObject("snippet") ?: continue
                if (id.isBlank()) continue
                base += YtItem(id, unescape(sn.optString("title")), unescape(sn.optString("channelTitle")))
            }
            val durations = try {
                fetchDurations(apiKey, base.map { it.videoId })
            } catch (_: Exception) {
                emptyMap()
            }
            YtPage(
                items = base.map { it.copy(durationMs = durations[it.videoId] ?: 0L) },
                next = root.optString("nextPageToken").ifBlank { null }
            )
        }

    /** Most popular music videos right now in [region]. */
    suspend fun trending(apiKey: String, region: String): YtPage = withContext(Dispatchers.IO) {
        val url = "https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails,status" +
            "&chart=mostPopular&videoCategoryId=10&maxResults=30" +
            "&regionCode=${enc(region)}&key=${enc(apiKey)}"
        val arr = JSONObject(httpGet(url)).optJSONArray("items") ?: JSONArray()
        val out = ArrayList<YtItem>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val sn = o.optJSONObject("snippet") ?: continue
            if (o.optJSONObject("status")?.optBoolean("embeddable", true) == false) continue
            out += YtItem(
                videoId = o.optString("id"),
                title = unescape(sn.optString("title")),
                author = unescape(sn.optString("channelTitle")),
                durationMs = isoToMs(o.optJSONObject("contentDetails")?.optString("duration").orEmpty())
            )
        }
        YtPage(out, null)
    }

    /** Title + channel via YouTube's public oEmbed endpoint (no API key needed). */
    suspend fun fetchInfo(id: String): YtItem = withContext(Dispatchers.IO) {
        try {
            val watch = enc("https://www.youtube.com/watch?v=$id")
            val o = JSONObject(httpGet("https://www.youtube.com/oembed?format=json&url=$watch"))
            YtItem(id, o.optString("title", "YouTube video"), o.optString("author_name"))
        } catch (_: Exception) {
            YtItem(id, "YouTube video $id", "")
        }
    }
}

/** Saves the YouTube list and favourite stations on the device. */
class Store(context: Context) {
    private val prefs = context.getSharedPreferences("pulse_store", Context.MODE_PRIVATE)

    fun loadYoutube(): List<YtItem> = readArray("yt") {
        YtItem(it.getString("id"), it.optString("title"), it.optString("author"))
    }

    fun saveYoutube(items: List<YtItem>) = writeArray("yt", items) {
        JSONObject().put("id", it.videoId).put("title", it.title).put("author", it.author)
    }

    fun loadFavorites(): List<Station> = readArray("fav") {
        Station(
            id = it.getString("id"),
            name = it.optString("name"),
            url = it.optString("url"),
            country = it.optString("country"),
            tags = it.optString("tags"),
            favicon = it.optString("favicon"),
            bitrate = it.optInt("bitrate", 0)
        )
    }

    fun saveFavorites(items: List<Station>) = writeArray("fav", items) {
        JSONObject()
            .put("id", it.id).put("name", it.name).put("url", it.url)
            .put("country", it.country).put("tags", it.tags)
            .put("favicon", it.favicon).put("bitrate", it.bitrate)
    }

    private fun <T> readArray(key: String, map: (JSONObject) -> T): List<T> = try {
        val arr = JSONArray(prefs.getString(key, "[]"))
        List(arr.length()) { map(arr.getJSONObject(it)) }
    } catch (_: Exception) {
        emptyList()
    }

    private fun <T> writeArray(key: String, items: List<T>, map: (T) -> JSONObject) {
        val arr = JSONArray()
        items.forEach { arr.put(map(it)) }
        prefs.edit().putString(key, arr.toString()).apply()
    }
}
