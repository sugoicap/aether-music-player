package com.example.pulseplayer

import android.content.Context

enum class NpLayout { CLASSIC, MINIMAL, VINYL }
enum class AccentMode { ALBUM, MANUAL }
enum class ListMode { GRID, COMPACT, DETAILED }
enum class TrackAnim { SLIDE, FADE }

val AccentPresets: List<Long> = listOf(
    0xFF1DB954, 0xFF4F8CFF, 0xFFFF5A5F, 0xFFFFB020,
    0xFFB388FF, 0xFF18D2C8, 0xFFFF6FB5, 0xFFFFFFFF
)

data class AppSettings(
    val oled: Boolean = true,
    val accentMode: AccentMode = AccentMode.ALBUM,
    val manualAccent: Long = 0xFF1DB954,
    val layout: NpLayout = NpLayout.CLASSIC,
    val coverRadius: Int = 20,
    val blurBackground: Boolean = true,
    val trackAnim: TrackAnim = TrackAnim.SLIDE,
    val listMode: ListMode = ListMode.GRID,
    val gridColumns: Int = 2,
    val ytApiKey: String = ""
)

private inline fun <reified T : Enum<T>> enumOf(name: String?, default: T): T =
    enumValues<T>().firstOrNull { it.name == name } ?: default

class SettingsStore(context: Context) {
    private val p = context.getSharedPreferences("pulse_settings", Context.MODE_PRIVATE)

    fun load(): AppSettings {
        val d = AppSettings()
        return AppSettings(
            oled = p.getBoolean("oled", d.oled),
            accentMode = enumOf(p.getString("accentMode", null), d.accentMode),
            manualAccent = p.getLong("manualAccent", d.manualAccent),
            layout = enumOf(p.getString("layout", null), d.layout),
            coverRadius = p.getInt("coverRadius", d.coverRadius),
            blurBackground = p.getBoolean("blur", d.blurBackground),
            trackAnim = enumOf(p.getString("trackAnim", null), d.trackAnim),
            listMode = enumOf(p.getString("listMode", null), d.listMode),
            gridColumns = p.getInt("gridColumns", d.gridColumns),
            ytApiKey = p.getString("ytApiKey", "") ?: ""
        )
    }

    fun save(s: AppSettings) {
        p.edit()
            .putBoolean("oled", s.oled)
            .putString("accentMode", s.accentMode.name)
            .putLong("manualAccent", s.manualAccent)
            .putString("layout", s.layout.name)
            .putInt("coverRadius", s.coverRadius)
            .putBoolean("blur", s.blurBackground)
            .putString("trackAnim", s.trackAnim.name)
            .putString("listMode", s.listMode.name)
            .putInt("gridColumns", s.gridColumns)
            .putString("ytApiKey", s.ytApiKey)
            .apply()
    }
}
