@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.pulseplayer

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

@Composable
fun SettingsSheet(s: AppSettings, onChange: (AppSettings) -> Unit, onDismiss: () -> Unit) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
    ) {
        Column(
            Modifier
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp)
        ) {
            Section("Theme")
            SwitchRow("OLED true black", s.oled) { onChange(s.copy(oled = it)) }
            Label("Accent color")
            ChipRow(
                listOf("Album art" to AccentMode.ALBUM, "Custom" to AccentMode.MANUAL),
                s.accentMode
            ) { onChange(s.copy(accentMode = it)) }
            if (s.accentMode == AccentMode.MANUAL) {
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    AccentPresets.forEach { c ->
                        Spacer(
                            Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(Color(c))
                                .border(
                                    2.dp,
                                    if (c == s.manualAccent) Color.White else Color.Transparent,
                                    CircleShape
                                )
                                .clickable { onChange(s.copy(manualAccent = c)) }
                        )
                    }
                }
            }

            Section("Now playing")
            Label("Layout")
            ChipRow(
                listOf("Classic" to NpLayout.CLASSIC, "Minimal" to NpLayout.MINIMAL, "Vinyl" to NpLayout.VINYL),
                s.layout
            ) { onChange(s.copy(layout = it)) }
            Label("Cover corner radius: ${s.coverRadius} dp")
            Slider(
                value = s.coverRadius.toFloat(),
                onValueChange = { onChange(s.copy(coverRadius = it.roundToInt())) },
                valueRange = 0f..48f
            )
            SwitchRow("Blurred cover background", s.blurBackground) { onChange(s.copy(blurBackground = it)) }
            Label("Song change animation")
            ChipRow(
                listOf("Slide" to TrackAnim.SLIDE, "Fade" to TrackAnim.FADE),
                s.trackAnim
            ) { onChange(s.copy(trackAnim = it)) }

            Section("YouTube search")
            Text(
                "Search needs a free YouTube Data API key (Google Cloud Console). Paste it here. It is stored only on this phone.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = s.ytApiKey,
                onValueChange = { onChange(s.copy(ytApiKey = it.trim())) },
                placeholder = { Text("API key (starts with AIza...)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Section("Music library")
            Label("View")
            ChipRow(
                listOf("Grid" to ListMode.GRID, "Compact" to ListMode.COMPACT, "Detailed" to ListMode.DETAILED),
                s.listMode
            ) { onChange(s.copy(listMode = it)) }
            if (s.listMode == ListMode.GRID) {
                Label("Grid columns")
                ChipRow(
                    listOf("2" to 2, "3" to 3, "4" to 4),
                    s.gridColumns
                ) { onChange(s.copy(gridColumns = it)) }
            }
        }
    }
}

@Composable
private fun Section(title: String) {
    Text(
        title.uppercase(),
        style = MaterialTheme.typography.labelMedium,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 24.dp, bottom = 8.dp)
    )
}

@Composable
private fun Label(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(top = 12.dp, bottom = 6.dp)
    )
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(top = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChecked)
    }
}

@Composable
private fun <T> ChipRow(options: List<Pair<String, T>>, selected: T, onSelect: (T) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { (label, value) ->
            FilterChip(
                selected = value == selected,
                onClick = { onSelect(value) },
                label = {
                    Text(
                        label,
                        fontWeight = if (value == selected) FontWeight.SemiBold else FontWeight.Normal
                    )
                }
            )
        }
    }
}
