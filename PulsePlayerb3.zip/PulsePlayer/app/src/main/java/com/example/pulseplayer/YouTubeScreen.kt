package com.example.pulseplayer

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SmartDisplay
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle

/**
 * Search YouTube music (or paste a link), tap a result to play it, tap the heart to keep it in Saved.
 * The video itself is drawn by the persistent player view in PulseApp, which sits on top of the
 * first [topInset] of this screen.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun YouTubeScreen(vm: PlayerViewModel, topInset: Dp, onOpenSettings: () -> Unit) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val results by vm.ytResults.collectAsStateWithLifecycle()
    val saved by vm.ytItems.collectAsStateWithLifecycle()
    val loading by vm.ytLoading.collectAsStateWithLifecycle()
    val error by vm.ytError.collectAsStateWithLifecycle()
    val hasMore by vm.ytHasMore.collectAsStateWithLifecycle()
    val now by vm.now.collectAsStateWithLifecycle()

    var query by rememberSaveable { mutableStateOf("") }
    var showSaved by rememberSaveable { mutableStateOf(false) }
    val hasKey = settings.ytApiKey.isNotBlank()

    // Show trending music as soon as the tab opens (and as soon as a key is added)
    LaunchedEffect(hasKey) {
        if (hasKey && results.isEmpty()) vm.ytSearch("")
    }

    fun submit() {
        showSaved = false
        vm.ytSearch(query)
        if (YouTubeRepository.extractVideoId(query) != null) query = ""
    }

    val list = if (showSaved) saved else results

    Column(Modifier.fillMaxSize()) {
        Spacer(Modifier.height(topInset))

        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            placeholder = { Text("Search songs, artists or paste a link") },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { submit() }),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        )

        Row(
            Modifier.padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = !showSaved,
                onClick = { showSaved = false },
                label = { Text(if (query.isBlank() && results.isNotEmpty()) "Trending" else "Results") }
            )
            FilterChip(
                selected = showSaved,
                onClick = { showSaved = true },
                label = { Text("Saved (${saved.size})") }
            )
        }

        if (loading) {
            LinearProgressIndicator(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp)
            )
        }

        when {
            !showSaved && !hasKey -> Column(Modifier.padding(24.dp)) {
                Text(
                    "To search YouTube, add a free YouTube Data API key in Settings. You can still paste a link above to play a song.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(12.dp))
                Button(onClick = onOpenSettings) { Text("Open settings") }
            }

            !showSaved && error != null -> Column(Modifier.padding(24.dp)) {
                Text(error.orEmpty(), color = MaterialTheme.colorScheme.error)
                Row {
                    TextButton(onClick = { vm.ytSearch(query) }) { Text("Retry") }
                    TextButton(onClick = onOpenSettings) { Text("Settings") }
                }
            }

            list.isEmpty() && !loading -> Text(
                if (showSaved) "Tap the heart on a song to keep it here." else "Nothing found. Try another search.",
                modifier = Modifier.padding(24.dp),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            else -> LazyColumn(Modifier.fillMaxSize()) {
                itemsIndexed(list, key = { _, entry -> entry.videoId }) { index, item ->
                    val current = now.source == Source.YOUTUBE && now.mediaId == item.videoId
                    val isSaved = saved.any { it.videoId == item.videoId }
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { vm.playYoutubeFrom(list, index) }
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Artwork(item.thumb, 56.dp, Icons.Filled.SmartDisplay)
                        Column(
                            Modifier
                                .weight(1f)
                                .padding(horizontal = 14.dp)
                        ) {
                            Text(
                                item.title,
                                style = MaterialTheme.typography.titleMedium,
                                color = if (current) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                            val meta = listOf(
                                item.author,
                                if (item.durationMs > 0) formatTime(item.durationMs) else ""
                            ).filter { it.isNotBlank() }.joinToString(" · ")
                            if (meta.isNotBlank()) {
                                Text(
                                    meta,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                        IconButton(onClick = { vm.toggleSaveYoutube(item) }) {
                            Icon(
                                if (isSaved) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                                contentDescription = if (isSaved) "Remove from saved" else "Save",
                                tint = if (isSaved) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
                if (!showSaved && hasMore) {
                    item(key = "more") {
                        TextButton(
                            onClick = { vm.ytLoadMore() },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(8.dp)
                        ) { Text("Load more") }
                    }
                }
            }
        }
    }
}
