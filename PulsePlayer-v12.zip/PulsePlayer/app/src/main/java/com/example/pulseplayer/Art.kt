package com.example.pulseplayer

import android.app.Application
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.BitmapDrawable
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.util.Size
import androidx.compose.animation.animateColorAsState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.palette.graphics.Palette
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.decode.DataSource
import coil.fetch.DrawableResult
import coil.fetch.FetchResult
import coil.fetch.Fetcher
import coil.imageLoader
import coil.key.Keyer
import coil.request.ImageRequest
import coil.request.Options
import coil.request.SuccessResult
import coil.size.Dimension
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Cover art of a local audio file (thumbnail from MediaStore, or the picture embedded in the file). */
data class LocalArt(val uri: Uri)

class LocalArtKeyer : Keyer<LocalArt> {
    override fun key(data: LocalArt, options: Options): String =
        "localart:" + data.uri.toString() + ":" + (if (((options.size.width as? coil.size.Dimension.Pixels)?.px ?: 400) <= 256) "s" else "l")
}

class LocalArtFetcher(
    private val context: Context,
    private val data: LocalArt,
    private val options: Options
) : Fetcher {

    override suspend fun fetch(): FetchResult? = withContext(Dispatchers.IO) {
        val bitmap = load() ?: return@withContext null
        DrawableResult(
            drawable = BitmapDrawable(context.resources, bitmap),
            isSampled = false,
            dataSource = DataSource.DISK
        )
    }

    private fun load(): Bitmap? {
        val px = ((options.size.width as? Dimension.Pixels)?.px ?: 400).coerceIn(96, 1400)
        // Small list covers: the fast system thumbnail is enough.
        // Big covers (Now Playing): the thumbnail is low resolution, so use the picture embedded in the file.
        return if (px <= 256) {
            thumbnail(px) ?: embedded(px)
        } else {
            embedded(px) ?: thumbnail(px)
        }
    }

    private fun thumbnail(px: Int): Bitmap? {
        if (Build.VERSION.SDK_INT < 29) return null
        return try {
            context.contentResolver.loadThumbnail(data.uri, Size(px, px), null)
        } catch (_: Exception) {
            null
        }
    }

    private fun embedded(px: Int): Bitmap? = try {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(context, data.uri)
            val bytes = r.embeddedPicture
            if (bytes != null) {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
                var sample = 1
                while (bounds.outWidth / (sample * 2) >= px) sample *= 2
                BitmapFactory.decodeByteArray(
                    bytes, 0, bytes.size,
                    BitmapFactory.Options().apply { inSampleSize = sample }
                )
            } else {
                null
            }
        } finally {
            r.release()
        }
    } catch (_: Exception) {
        null
    }

    class Factory(private val context: Context) : Fetcher.Factory<LocalArt> {
        override fun create(data: LocalArt, options: Options, imageLoader: ImageLoader): Fetcher =
            LocalArtFetcher(context, data, options)
    }
}

class PulseApplication : Application(), ImageLoaderFactory {
    override fun newImageLoader(): ImageLoader =
        ImageLoader.Builder(this)
            .components {
                add(LocalArtKeyer())
                add(LocalArtFetcher.Factory(this@PulseApplication))
            }
            .crossfade(true)
            .build()
}

fun ensureLight(c: Color): Color {
    var x = c
    var i = 0
    while (x.luminance() < 0.28f && i < 8) {
        x = lerp(x, Color.White, 0.18f)
        i++
    }
    return x
}

/** Picks an accent colour from the cover (Material You style). Falls back to [fallback]. */
@Composable
fun rememberArtColor(model: Any?, fallback: Color): Color {
    val context = LocalContext.current
    var target by remember { mutableStateOf(fallback) }
    LaunchedEffect(model, fallback) {
        if (model == null || (model is String && model.isBlank())) {
            target = fallback
            return@LaunchedEffect
        }
        val request = ImageRequest.Builder(context)
            .data(model)
            .allowHardware(false)
            .size(128)
            .build()
        val result = context.imageLoader.execute(request)
        val bitmap = ((result as? SuccessResult)?.drawable as? BitmapDrawable)?.bitmap
        target = if (bitmap != null) {
            val palette = withContext(Dispatchers.Default) { Palette.from(bitmap).generate() }
            val sw = palette.vibrantSwatch
                ?: palette.lightVibrantSwatch
                ?: palette.mutedSwatch
                ?: palette.dominantSwatch
            if (sw != null) ensureLight(Color(sw.rgb)) else fallback
        } else {
            fallback
        }
    }
    // No colour animation: animating it would re-draw the whole app on every frame
    return target
}
