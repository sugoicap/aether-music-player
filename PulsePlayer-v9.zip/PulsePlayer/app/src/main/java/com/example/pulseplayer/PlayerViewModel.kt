package com.example.pulseplayer

import android.app.Application
import android.content.ComponentName
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/**
 * Owns playback for both sources (local music and online radio). Both play through Media3
 * in a background service. Starting one replaces the other.
 */
class PlayerViewModel(private val app: Application) : AndroidViewModel(app) {

    private val store = Store(app)
    private val settingsStore = SettingsStore(app)
    val settings = MutableStateFlow(settingsStore.load())

    val tab = MutableStateFlow(Tab.LIBRARY)
    val tracks = MutableStateFlow<List<Track>>(emptyList())
    val favorites = MutableStateFlow(store.loadFavorites())
    val now = MutableStateFlow(NowPlaying())
    val progress = MutableStateFlow(Progress())
    val message = MutableStateFlow<String?>(null)

    // Library search
    val libSearchOpen = MutableStateFlow(false)
    val libQuery = MutableStateFlow("")

    // Radio search + data
    val radioSearchOpen = MutableStateFlow(false)
    val radioQuery = MutableStateFlow("")
    val stations = MutableStateFlow<List<Station>>(emptyList())
    val countries = MutableStateFlow<List<Facet>>(emptyList())
    val languages = MutableStateFlow<List<Facet>>(emptyList())
    val facetStations = MutableStateFlow<List<Station>>(emptyList())
    val radioLoading = MutableStateFlow(false)
    val radioError = MutableStateFlow<String?>(null)

    /** Only changes when the track/station changes, so lists don't recompose every tick. */
    val currentLocalId: StateFlow<String> = now
        .map { if (it.source == Source.LOCAL) it.mediaId else "" }
        .distinctUntilChanged()
        .stateIn(viewModelScope, SharingStarted.Eagerly, "")
    val currentStationId: StateFlow<String> = now
        .map { if (it.source == Source.RADIO) it.mediaId else "" }
        .distinctUntilChanged()
        .stateIn(viewModelScope, SharingStarted.Eagerly, "")

    private val S get() = Str(settings.value.lang)
    private var controller: MediaController? = null
    private var radioList: List<Station> = emptyList()
    private var radioIndex = -1
    private var allJob: Job? = null
    private var facetJob: Job? = null
    private var listJob: Job? = null
    private var lastAllQuery: String? = null
    private var lastFacetKey: String? = null

    private val playerListener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) {
            refreshFromController()
        }

        override fun onPlayerError(error: PlaybackException) {
            message.value = S.errPlayback(error.errorCodeName)
        }
    }

    init {
        val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
        val future = MediaController.Builder(app, token).buildAsync()
        future.addListener({
            try {
                val c = future.get()
                controller = c
                c.addListener(playerListener)
                restoreFromController(c)
            } catch (e: Exception) {
                message.value = S.errService
            }
        }, ContextCompat.getMainExecutor(app))

        // Progress ticker: touches only the small Progress flow
        viewModelScope.launch {
            while (true) {
                delay(250)
                val c = controller ?: continue
                val s = now.value.source
                if (s == Source.NONE) continue
                if (!c.isPlaying && progress.value.positionMs == c.currentPosition) continue
                val p = Progress(
                    positionMs = c.currentPosition.coerceAtLeast(0L),
                    durationMs = if (s == Source.LOCAL) c.duration.coerceAtLeast(0L) else 0L
                )
                if (p != progress.value) progress.value = p
            }
        }
    }

    /** The service keeps playing when the app is closed; pick up its state when we come back. */
    private fun restoreFromController(c: MediaController) {
        val item = c.currentMediaItem ?: return
        if (now.value.source != Source.NONE) return
        when (item.mediaMetadata.extras?.getString("src")) {
            "radio" -> {
                val st = Station(
                    id = item.mediaId,
                    name = item.mediaMetadata.title?.toString().orEmpty(),
                    url = item.localConfiguration?.uri?.toString().orEmpty(),
                    country = item.mediaMetadata.artist?.toString().orEmpty(),
                    tags = "",
                    favicon = item.mediaMetadata.artworkUri?.toString().orEmpty(),
                    bitrate = 0
                )
                radioList = (listOf(st) + favorites.value).distinctBy { it.id }
                radioIndex = 0
                now.value = NowPlaying(Source.RADIO, mediaId = st.id, title = st.name, subtitle = st.subtitle)
            }
            "local" -> now.value = NowPlaying(Source.LOCAL, mediaId = item.mediaId)
            else -> return
        }
        refreshFromController()
    }

    // ---------- Settings ----------

    fun updateSettings(s: AppSettings) {
        val langChanged = s.lang != settings.value.lang
        settings.value = s
        settingsStore.save(s)
        if (langChanged && tracks.value.isNotEmpty()) loadLibrary()
    }

    // ---------- Library ----------

    fun loadLibrary() {
        viewModelScope.launch {
            try {
                tracks.value = LocalMusicRepository.load(app, S.unknownArtist)
            } catch (e: Exception) {
                message.value = S.errLibrary
            }
        }
    }

    fun playLocal(list: List<Track>, index: Int, shuffle: Boolean = false) {
        val c = controller ?: run {
            message.value = S.playerStarting
            return
        }
        if (list.isEmpty()) return
        now.value = NowPlaying(Source.LOCAL)
        progress.value = Progress()
        c.shuffleModeEnabled = shuffle
        c.repeatMode = Player.REPEAT_MODE_ALL
        c.setMediaItems(list.map { it.toMediaItem() }, index.coerceIn(list.indices), 0L)
        c.prepare()
        c.play()
        refreshFromController()
    }

    // ---------- Radio ----------

    /** "Összes" tab: search the whole directory. Empty query = most popular stations. */
    fun searchRadio(query: String, tag: String?, force: Boolean = false) {
        val q = query.trim()
        if (!force && q == lastAllQuery && stations.value.isNotEmpty()) return
        lastAllQuery = q
        allJob?.cancel()
        allJob = viewModelScope.launch {
            if (q.isNotEmpty()) delay(450) // debounce typing
            radioLoading.value = true
            radioError.value = null
            try {
                stations.value = RadioRepository.search(q, tag)
            } catch (e: Exception) {
                lastAllQuery = null
                radioError.value = S.errRadio
            }
            radioLoading.value = false
        }
    }

    fun loadCountries(force: Boolean = false) {
        if (!force && countries.value.isNotEmpty()) return
        loadFacets { countries.value = RadioRepository.countries() }
    }

    fun loadLanguages(force: Boolean = false) {
        if (!force && languages.value.isNotEmpty()) return
        loadFacets { languages.value = RadioRepository.languages() }
    }

    private fun loadFacets(block: suspend () -> Unit) {
        listJob?.cancel()
        listJob = viewModelScope.launch {
            radioLoading.value = true
            radioError.value = null
            try {
                block()
            } catch (e: Exception) {
                radioError.value = S.errRadio
            }
            radioLoading.value = false
        }
    }

    /** Stations of one country/language, optionally filtered by the search text. */
    fun loadFacetStations(kind: FacetKind, value: String, query: String, force: Boolean = false) {
        val q = query.trim()
        val key = "$kind|$value|$q"
        if (!force && key == lastFacetKey) return
        val sameFacet = lastFacetKey?.startsWith("$kind|$value|") == true
        lastFacetKey = key
        if (!sameFacet) facetStations.value = emptyList()
        facetJob?.cancel()
        facetJob = viewModelScope.launch {
            if (q.isNotEmpty()) delay(450)
            radioLoading.value = true
            radioError.value = null
            try {
                facetStations.value = RadioRepository.byFacet(kind, value, q)
            } catch (e: Exception) {
                lastFacetKey = null
                radioError.value = S.errRadio
            }
            radioLoading.value = false
        }
    }

    fun leaveFacet() {
        facetJob?.cancel()
        lastFacetKey = null
        facetStations.value = emptyList()
        radioLoading.value = false
        radioError.value = null
    }

    fun playStation(list: List<Station>, index: Int) {
        val c = controller ?: run {
            message.value = S.playerStarting
            return
        }
        val station = list.getOrNull(index) ?: return
        radioList = list
        radioIndex = index
        now.value = NowPlaying(Source.RADIO, mediaId = station.id, title = station.name, subtitle = station.subtitle)
        progress.value = Progress()
        c.shuffleModeEnabled = false
        c.repeatMode = Player.REPEAT_MODE_OFF
        c.setMediaItem(station.toMediaItem())
        c.prepare()
        c.play()
        viewModelScope.launch { RadioRepository.countClick(station.id) }
    }

    fun toggleFavorite(station: Station) {
        favorites.update { list ->
            if (list.any { it.id == station.id }) list.filterNot { it.id == station.id } else list + station
        }
        store.saveFavorites(favorites.value)
    }

    // ---------- Transport controls ----------

    fun togglePlayPause() {
        controller?.let {
            if (it.playWhenReady && it.playbackState != Player.STATE_ENDED) it.pause() else it.play()
        }
    }

    fun next() {
        when (now.value.source) {
            Source.LOCAL -> controller?.seekToNextMediaItem()
            Source.RADIO -> if (radioList.isNotEmpty()) playStation(radioList, (radioIndex + 1) % radioList.size)
            Source.NONE -> {}
        }
    }

    fun previous() {
        when (now.value.source) {
            Source.LOCAL -> controller?.seekToPrevious()
            Source.RADIO -> if (radioList.isNotEmpty()) {
                playStation(radioList, (radioIndex - 1 + radioList.size) % radioList.size)
            }
            Source.NONE -> {}
        }
    }

    fun seekTo(ms: Long) {
        if (now.value.source == Source.LOCAL) {
            controller?.seekTo(ms)
            progress.update { it.copy(positionMs = ms) }
        }
    }

    fun toggleShuffle() {
        val c = controller ?: return
        c.shuffleModeEnabled = !c.shuffleModeEnabled
        refreshFromController()
    }

    fun cycleRepeat() {
        val c = controller ?: return
        c.repeatMode = when (c.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
        refreshFromController()
    }

    // ---------- Internals ----------

    private fun refreshFromController() {
        val c = controller ?: return
        val source = now.value.source
        if (source == Source.NONE) return

        val meta = c.mediaMetadata
        val active = c.playWhenReady &&
            c.playbackState != Player.STATE_ENDED &&
            c.playbackState != Player.STATE_IDLE
        val id = c.currentMediaItem?.mediaId.orEmpty()

        if (source == Source.LOCAL) {
            val art = c.currentMediaItem?.localConfiguration?.uri?.let { u -> LocalArt(u) }
            val next = NowPlaying(
                source = Source.LOCAL,
                mediaId = id,
                title = meta.title?.toString().orEmpty(),
                subtitle = meta.artist?.toString().orEmpty(),
                artwork = art,
                shuffle = c.shuffleModeEnabled,
                repeat = c.repeatMode,
                isPlaying = active
            )
            if (next != now.value) now.value = next
        } else {
            val station = radioList.getOrNull(radioIndex)
            // Radio streams push the current song title as live metadata
            val live = meta.title?.toString().orEmpty()
            val next = NowPlaying(
                source = Source.RADIO,
                mediaId = id,
                title = station?.name ?: live,
                subtitle = if (live.isNotBlank() && live != station?.name) live else station?.subtitle.orEmpty(),
                artwork = station?.favicon?.takeIf { f -> f.isNotBlank() },
                shuffle = false,
                repeat = 0,
                isPlaying = active
            )
            if (next != now.value) now.value = next
        }
    }

    override fun onCleared() {
        controller?.release()
        super.onCleared()
    }
}
