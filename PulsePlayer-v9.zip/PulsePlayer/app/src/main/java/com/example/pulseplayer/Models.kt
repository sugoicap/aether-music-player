package com.example.pulseplayer

import android.net.Uri
import android.os.Bundle
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata

data class Track(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val durationMs: Long,
    val uri: Uri,
    val artwork: Uri?,
    val format: String = "",
    val bitrateKbps: Int = 0,
    val albumId: Long = 0L,
    val trackNo: Int = 0,
    val folder: String = "",
    val folderPath: String = ""
) {
    val art: Any get() = LocalArt(uri)

    fun toMediaItem(): MediaItem = MediaItem.Builder()
        .setMediaId(id.toString())
        .setUri(uri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setArtist(artist)
                .setAlbumTitle(album)
                .setArtworkUri(artwork)
                .setExtras(Bundle().apply { putString("src", "local") })
                .build()
        )
        .build()
}

data class Station(
    val id: String,
    val name: String,
    val url: String,
    val country: String,
    val tags: String,
    val favicon: String,
    val bitrate: Int
) {
    val subtitle: String
        get() = listOf(
            country,
            tags.split(",").map { it.trim() }.filter { it.isNotEmpty() }.take(2).joinToString(", "),
            if (bitrate > 0) "$bitrate kbps" else ""
        ).filter { it.isNotBlank() }.joinToString(" · ")

    fun toMediaItem(): MediaItem = MediaItem.Builder()
        .setMediaId(id)
        .setUri(url)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(name)
                .setArtist(country)
                .setArtworkUri(favicon.takeIf { it.isNotBlank() }?.let { Uri.parse(it) })
                .setExtras(Bundle().apply { putString("src", "radio") })
                .build()
        )
        .build()
}

enum class Source { NONE, LOCAL, RADIO }

data class NowPlaying(
    val source: Source = Source.NONE,
    val mediaId: String = "",
    val title: String = "",
    val subtitle: String = "",
    val artwork: Any? = null,
    val shuffle: Boolean = false,
    val repeat: Int = 0,
    val isPlaying: Boolean = false
)

/** Changes every 250 ms while playing, so it lives apart from [NowPlaying]. */
data class Progress(val positionMs: Long = 0L, val durationMs: Long = 0L)

enum class FacetKind { COUNTRY, LANGUAGE }

/** A country or a language of the radio directory, with its number of stations. */
data class Facet(val name: String, val count: Int) {
    val label: String get() = name.replaceFirstChar { it.uppercase() }
}

fun formatTime(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}
