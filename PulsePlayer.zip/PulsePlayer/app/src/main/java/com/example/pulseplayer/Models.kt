package com.example.pulseplayer

import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata

data class Track(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val durationMs: Long,
    val uri: Uri,
    val artwork: Uri?
) {
    fun toMediaItem(): MediaItem = MediaItem.Builder()
        .setMediaId(id.toString())
        .setUri(uri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setArtist(artist)
                .setAlbumTitle(album)
                .setArtworkUri(artwork)
                .build()
        )
        .build()
}

data class Station(
    val id: String,
    val name: String,
    val url: String,
    val country: String,
    val tags: String,
    val favicon: String,
    val bitrate: Int
) {
    val subtitle: String
        get() = listOf(
            country,
            tags.split(",").map { it.trim() }.filter { it.isNotEmpty() }.take(2).joinToString(", "),
            if (bitrate > 0) "$bitrate kbps" else ""
        ).filter { it.isNotBlank() }.joinToString(" · ")

    fun toMediaItem(): MediaItem = MediaItem.Builder()
        .setMediaId(id)
        .setUri(url)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(name)
                .setArtist(country)
                .setArtworkUri(favicon.takeIf { it.isNotBlank() }?.let { Uri.parse(it) })
                .build()
        )
        .build()
}

data class YtItem(
    val videoId: String,
    val title: String,
    val author: String
) {
    val thumb: String get() = "https://i.ytimg.com/vi/$videoId/mqdefault.jpg"
}

enum class Source { NONE, LOCAL, RADIO, YOUTUBE }

data class NowPlaying(
    val source: Source = Source.NONE,
    val mediaId: String = "",
    val title: String = "",
    val subtitle: String = "",
    val artwork: String? = null,
    val isPlaying: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L
)

fun formatTime(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}
