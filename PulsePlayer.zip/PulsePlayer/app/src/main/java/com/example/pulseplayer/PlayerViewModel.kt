package com.example.pulseplayer

import android.app.Application
import android.content.ComponentName
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.PlayerConstants
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.AbstractYouTubePlayerListener
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/**
 * One place that owns all three sources:
 *  - LOCAL and RADIO play through Media3 (background service)
 *  - YOUTUBE plays through the embedded YouTube player
 * Only one source plays at a time; starting one pauses the others.
 */
class PlayerViewModel(private val app: Application) : AndroidViewModel(app) {

    private val store = Store(app)

    val tab = MutableStateFlow(Tab.LIBRARY)
    val tracks = MutableStateFlow<List<Track>>(emptyList())
    val stations = MutableStateFlow<List<Station>>(emptyList())
    val favorites = MutableStateFlow(store.loadFavorites())
    val radioLoading = MutableStateFlow(false)
    val radioError = MutableStateFlow<String?>(null)
    val ytItems = MutableStateFlow(store.loadYoutube())
    val now = MutableStateFlow(NowPlaying())
    val message = MutableStateFlow<String?>(null)

    private var controller: MediaController? = null
    private var ytPlayer: YouTubePlayer? = null
    private var pendingYt: String? = null
    private var ytIndex = -1
    private var radioList: List<Station> = emptyList()
    private var radioIndex = -1
    private var radioJob: Job? = null

    private val playerListener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) {
            refreshFromController()
        }

        override fun onPlayerError(error: PlaybackException) {
            message.value = "Playback error: ${error.errorCodeName}"
        }
    }

    val ytListener = object : AbstractYouTubePlayerListener() {
        override fun onReady(youTubePlayer: YouTubePlayer) {
            ytPlayer = youTubePlayer
            pendingYt?.let {
                youTubePlayer.loadVideo(it, 0f)
                pendingYt = null
            }
        }

        override fun onStateChange(youTubePlayer: YouTubePlayer, state: PlayerConstants.PlayerState) {
            if (now.value.source != Source.YOUTUBE) return
            when (state) {
                PlayerConstants.PlayerState.PLAYING -> now.update { it.copy(isPlaying = true) }
                PlayerConstants.PlayerState.PAUSED -> now.update { it.copy(isPlaying = false) }
                PlayerConstants.PlayerState.ENDED -> advanceYoutube(wrap = true)
                else -> {}
            }
        }

        override fun onCurrentSecond(youTubePlayer: YouTubePlayer, second: Float) {
            if (now.value.source == Source.YOUTUBE) {
                now.update { it.copy(positionMs = (second * 1000).toLong()) }
            }
        }

        override fun onVideoDuration(youTubePlayer: YouTubePlayer, duration: Float) {
            if (now.value.source == Source.YOUTUBE) {
                now.update { it.copy(durationMs = (duration * 1000).toLong()) }
            }
        }

        override fun onError(youTubePlayer: YouTubePlayer, error: PlayerConstants.PlayerError) {
            message.value = "This video can't be played in an embedded player"
            if (now.value.source == Source.YOUTUBE) advanceYoutube(wrap = false)
        }
    }

    init {
        val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
        val future = MediaController.Builder(app, token).buildAsync()
        future.addListener({
            try {
                controller = future.get().also { it.addListener(playerListener) }
            } catch (e: Exception) {
                message.value = "Couldn't connect to the audio service"
            }
        }, ContextCompat.getMainExecutor(app))

        // Progress ticker for LOCAL / RADIO (YouTube reports its own position)
        viewModelScope.launch {
            while (true) {
                delay(500)
                val c = controller ?: continue
                val s = now.value.source
                if (s == Source.LOCAL || s == Source.RADIO) {
                    now.update {
                        it.copy(
                            positionMs = c.currentPosition.coerceAtLeast(0L),
                            durationMs = if (s == Source.LOCAL) c.duration.coerceAtLeast(0L) else 0L
                        )
                    }
                }
            }
        }
    }

    // ---------- Library ----------

    fun loadLibrary() {
        viewModelScope.launch {
            try {
                tracks.value = LocalMusicRepository.load(app)
            } catch (e: Exception) {
                message.value = "Couldn't read your music library"
            }
        }
    }

    fun playLocal(list: List<Track>, index: Int, shuffle: Boolean = false) {
        val c = controller ?: run {
            message.value = "Player is still starting, try again"
            return
        }
        if (list.isEmpty()) return
        pauseYoutube()
        now.value = NowPlaying(Source.LOCAL)
        c.shuffleModeEnabled = shuffle
        c.repeatMode = Player.REPEAT_MODE_ALL
        c.setMediaItems(list.map { it.toMediaItem() }, index.coerceIn(list.indices), 0L)
        c.prepare()
        c.play()
        refreshFromController()
    }

    // ---------- Radio ----------

    fun searchRadio(query: String, tag: String?) {
        radioJob?.cancel()
        radioJob = viewModelScope.launch {
            radioLoading.value = true
            radioError.value = null
            try {
                stations.value = RadioRepository.search(query.trim(), tag)
            } catch (e: Exception) {
                radioError.value = "Couldn't reach the radio directory. Check your connection."
            }
            radioLoading.value = false
        }
    }

    fun playStation(list: List<Station>, index: Int) {
        val c = controller ?: run {
            message.value = "Player is still starting, try again"
            return
        }
        val station = list.getOrNull(index) ?: return
        pauseYoutube()
        radioList = list
        radioIndex = index
        now.value = NowPlaying(Source.RADIO, mediaId = station.id, title = station.name, subtitle = station.subtitle)
        c.shuffleModeEnabled = false
        c.repeatMode = Player.REPEAT_MODE_OFF
        c.setMediaItem(station.toMediaItem())
        c.prepare()
        c.play()
        viewModelScope.launch { RadioRepository.countClick(station.id) }
    }

    fun toggleFavorite(station: Station) {
        favorites.update { list ->
            if (list.any { it.id == station.id }) list.filterNot { it.id == station.id } else list + station
        }
        store.saveFavorites(favorites.value)
    }

    // ---------- YouTube ----------

    fun addYoutube(input: String, playNow: Boolean = false) {
        val id = YouTubeRepository.extractVideoId(input) ?: run {
            message.value = "That doesn't look like a YouTube link"
            return
        }
        val existing = ytItems.value.indexOfFirst { it.videoId == id }
        if (existing >= 0) {
            if (playNow) playYoutube(existing) else message.value = "Already in your list"
            return
        }
        viewModelScope.launch {
            val item = YouTubeRepository.fetchInfo(id)
            ytItems.update { it + item }
            store.saveYoutube(ytItems.value)
            if (playNow) playYoutube(ytItems.value.lastIndex)
        }
    }

    fun removeYoutube(item: YtItem) {
        ytItems.update { list -> list.filterNot { it.videoId == item.videoId } }
        store.saveYoutube(ytItems.value)
        if (now.value.source == Source.YOUTUBE) {
            ytIndex = ytItems.value.indexOfFirst { it.videoId == now.value.mediaId }
        }
    }

    fun playYoutube(index: Int) {
        val item = ytItems.value.getOrNull(index) ?: return
        controller?.pause()
        ytIndex = index
        now.value = NowPlaying(
            Source.YOUTUBE,
            mediaId = item.videoId,
            title = item.title,
            subtitle = item.author,
            artwork = item.thumb,
            isPlaying = true
        )
        val player = ytPlayer
        if (player != null) player.loadVideo(item.videoId, 0f) else pendingYt = item.videoId
    }

    private fun advanceYoutube(wrap: Boolean) {
        val size = ytItems.value.size
        if (size == 0) return
        val next = ytIndex + 1
        when {
            next < size -> playYoutube(next)
            wrap -> playYoutube(0)
        }
    }

    private fun pauseYoutube() {
        ytPlayer?.pause()
    }

    // ---------- Transport controls (work for any source) ----------

    fun togglePlayPause() {
        when (now.value.source) {
            Source.YOUTUBE -> if (now.value.isPlaying) ytPlayer?.pause() else ytPlayer?.play()
            Source.LOCAL, Source.RADIO -> controller?.let {
                if (it.playWhenReady && it.playbackState != Player.STATE_ENDED) it.pause() else it.play()
            }
            Source.NONE -> {}
        }
    }

    fun next() {
        when (now.value.source) {
            Source.LOCAL -> controller?.seekToNextMediaItem()
            Source.RADIO -> if (radioList.isNotEmpty()) playStation(radioList, (radioIndex + 1) % radioList.size)
            Source.YOUTUBE -> advanceYoutube(wrap = true)
            Source.NONE -> {}
        }
    }

    fun previous() {
        when (now.value.source) {
            Source.LOCAL -> controller?.seekToPrevious()
            Source.RADIO -> if (radioList.isNotEmpty()) {
                playStation(radioList, (radioIndex - 1 + radioList.size) % radioList.size)
            }
            Source.YOUTUBE -> {
                if (now.value.positionMs > 3000) {
                    ytPlayer?.seekTo(0f)
                } else {
                    playYoutube(if (ytIndex > 0) ytIndex - 1 else ytItems.value.lastIndex)
                }
            }
            Source.NONE -> {}
        }
    }

    fun seekTo(ms: Long) {
        when (now.value.source) {
            Source.YOUTUBE -> ytPlayer?.seekTo(ms / 1000f)
            Source.LOCAL -> controller?.seekTo(ms)
            else -> {}
        }
    }

    // ---------- Internals ----------

    private fun refreshFromController() {
        val c = controller ?: return
        val source = now.value.source
        if (source != Source.LOCAL && source != Source.RADIO) return

        val meta = c.mediaMetadata
        val active = c.playWhenReady &&
            c.playbackState != Player.STATE_ENDED &&
            c.playbackState != Player.STATE_IDLE
        val id = c.currentMediaItem?.mediaId.orEmpty()

        if (source == Source.LOCAL) {
            now.update {
                it.copy(
                    mediaId = id,
                    title = meta.title?.toString().orEmpty(),
                    subtitle = meta.artist?.toString().orEmpty(),
                    artwork = meta.artworkUri?.toString(),
                    isPlaying = active
                )
            }
        } else {
            val station = radioList.getOrNull(radioIndex)
            // Radio streams push the current song title as live metadata
            val live = meta.title?.toString().orEmpty()
            now.update {
                it.copy(
                    mediaId = id,
                    title = station?.name ?: live,
                    subtitle = if (live.isNotBlank() && live != station?.name) live else station?.subtitle.orEmpty(),
                    artwork = station?.favicon?.takeIf { f -> f.isNotBlank() },
                    isPlaying = active
                )
            }
        }
    }

    override fun onCleared() {
        controller?.release()
        super.onCleared()
    }
}
