package com.example.pulseplayer

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlin.math.roundToInt

private enum class SettingsPage {
    GENERAL, PLAYER, LIBRARY, SOUND, ABOUT;

    fun label(s: Str) = when (this) {
        GENERAL -> s.pGeneral
        PLAYER -> s.pPlayer
        LIBRARY -> s.tabLibrary
        SOUND -> s.pSound
        ABOUT -> s.sAbout
    }
}

/** Full settings page with sub menus (same text-tab style as the library). */
@Composable
fun SettingsScreen(vm: PlayerViewModel) {
    val S = LocalStr.current
    val s by vm.settings.collectAsStateWithLifecycle()
    var pageIdx by rememberSaveable { mutableStateOf(SettingsPage.GENERAL.ordinal) }
    val page = SettingsPage.entries[pageIdx]
    val onChange = vm::updateSettings

    Column(Modifier.fillMaxSize()) {
        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(SettingsPage.entries.toList()) { p ->
                TextTab(p.label(S).uppercase(), p == page) { pageIdx = p.ordinal }
            }
        }
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp)
        ) {
            when (page) {
                SettingsPage.GENERAL -> GeneralPage(s, onChange)
                SettingsPage.PLAYER -> PlayerPage(s, onChange)
                SettingsPage.LIBRARY -> LibraryPage(s, onChange)
                SettingsPage.SOUND -> SoundPage()
                SettingsPage.ABOUT -> AboutPage()
            }
        }
    }
}

@Composable
private fun GeneralPage(s: AppSettings, onChange: (AppSettings) -> Unit) {
    val S = LocalStr.current
    Section(S.sLanguage)
    ChipRow(listOf("Magyar" to Lang.HU, "English" to Lang.EN), s.lang) { onChange(s.copy(lang = it)) }

    Section(S.sTheme)
    SwitchRow(S.sOled, s.oled) { onChange(s.copy(oled = it)) }
    Label(S.sAccent)
    ChipRow(
        listOf(S.sAlbumArt to AccentMode.ALBUM, S.sCustom to AccentMode.MANUAL),
        s.accentMode
    ) { onChange(s.copy(accentMode = it)) }
    if (s.accentMode == AccentMode.MANUAL) {
        Spacer(Modifier.height(12.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            AccentPresets.forEach { c ->
                Spacer(
                    Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(Color(c))
                        .border(2.dp, if (c == s.manualAccent) Color.White else Color.Transparent, CircleShape)
                        .clickable { onChange(s.copy(manualAccent = c)) }
                )
            }
        }
    }
}

@Composable
private fun PlayerPage(s: AppSettings, onChange: (AppSettings) -> Unit) {
    val S = LocalStr.current
    Section(S.sNowPlaying)
    Label(S.sLayout)
    ChipRow(
        listOf(S.sClassic to NpLayout.CLASSIC, S.sMinimal to NpLayout.MINIMAL, S.sVinyl to NpLayout.VINYL),
        s.layout
    ) { onChange(s.copy(layout = it)) }
    var radius by remember(s.coverRadius) { mutableFloatStateOf(s.coverRadius.toFloat()) }
    Label(S.sRadius(radius.roundToInt()))
    Slider(
        value = radius,
        onValueChange = { radius = it },
        onValueChangeFinished = { onChange(s.copy(coverRadius = radius.roundToInt())) },
        valueRange = 0f..48f
    )
    SwitchRow(S.sBlur, s.blurBackground) { onChange(s.copy(blurBackground = it)) }
    Label(S.sAnim)
    ChipRow(
        listOf(S.sSlide to TrackAnim.SLIDE, S.sFade to TrackAnim.FADE),
        s.trackAnim
    ) { onChange(s.copy(trackAnim = it)) }
}

@Composable
private fun LibraryPage(s: AppSettings, onChange: (AppSettings) -> Unit) {
    val S = LocalStr.current
    Section(S.sLibrary)
    Label(S.sView)
    ChipRow(
        listOf(S.sGrid to ListMode.GRID, S.sCompact to ListMode.COMPACT, S.sDetailed to ListMode.DETAILED),
        s.listMode
    ) { onChange(s.copy(listMode = it)) }
    if (s.listMode == ListMode.GRID) {
        Label(S.sColumns)
        ChipRow(listOf("2" to 2, "3" to 3, "4" to 4), s.gridColumns) { onChange(s.copy(gridColumns = it)) }
    }
}

@Composable
private fun SoundPage() {
    val S = LocalStr.current
    val st by AudioFx.state.collectAsStateWithLifecycle()
    val info = AudioFx.info

    Section(S.eqTitle)
    if (info == null) {
        Text(S.eqUnsupported, color = MaterialTheme.colorScheme.onSurfaceVariant)
        return
    }
    SwitchRow(S.eqEnable, st.enabled) { AudioFx.update(st.copy(enabled = it)) }
    Text(
        S.eqNote,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(top = 2.dp)
    )

    Label(S.eqPreset)
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FilterChip(
            selected = st.preset == -1,
            onClick = { },
            label = { Text(S.eqCustom) }
        )
        info.presets.forEachIndexed { i, name ->
            FilterChip(
                selected = st.preset == i,
                onClick = {
                    val lv = info.presetLevels[i].map { it.coerceIn(info.minLevel, info.maxLevel) }
                    AudioFx.update(st.copy(levels = lv, preset = i, enabled = true))
                },
                label = { Text(name) }
            )
        }
    }

    Section(S.eqBands)
    info.freqsHz.forEachIndexed { i, hz ->
        BandSlider(
            label = freqLabel(hz),
            level = st.levels.getOrElse(i) { 0 },
            min = info.minLevel,
            max = info.maxLevel
        ) { v, done ->
            val nl = st.levels.toMutableList()
            while (nl.size <= i) nl.add(0)
            nl[i] = v
            AudioFx.update(st.copy(levels = nl, preset = -1), save = done)
        }
    }

    if (info.bassSupported) {
        Section(S.eqBass)
        var bass by remember(st.bass) { mutableFloatStateOf(st.bass.toFloat()) }
        Slider(
            value = bass,
            onValueChange = {
                bass = it
                AudioFx.update(st.copy(bass = it.roundToInt()), save = false)
            },
            onValueChangeFinished = { AudioFx.update(st.copy(bass = bass.roundToInt()), save = true) },
            valueRange = 0f..1000f
        )
    }

    TextButton(
        onClick = { AudioFx.update(st.copy(levels = st.levels.map { 0 }, preset = -1, bass = 0)) },
        modifier = Modifier.padding(top = 16.dp)
    ) { Text(S.eqReset) }
}

private fun freqLabel(hz: Int): String = when {
    hz >= 1000 && hz % 1000 == 0 -> "${hz / 1000} kHz"
    hz >= 1000 -> "%.1f kHz".format(hz / 1000f)
    else -> "$hz Hz"
}

@Composable
private fun BandSlider(label: String, level: Int, min: Int, max: Int, onChange: (Int, Boolean) -> Unit) {
    var v by remember(level) { mutableFloatStateOf(level.toFloat()) }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
            label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.width(72.dp)
        )
        Slider(
            value = v,
            onValueChange = {
                v = it
                onChange(it.roundToInt(), false)
            },
            onValueChangeFinished = { onChange(v.roundToInt(), true) },
            valueRange = min.toFloat()..max.toFloat(),
            modifier = Modifier.weight(1f)
        )
        Text(
            "%+.1f dB".format(v / 100f),
            style = MaterialTheme.typography.labelMedium,
            textAlign = TextAlign.End,
            modifier = Modifier.width(64.dp)
        )
    }
}

@Composable
private fun AboutPage() {
    val S = LocalStr.current
    val context = LocalContext.current
    val uriHandler = LocalUriHandler.current
    val version = remember {
        try {
            context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: ""
        } catch (e: Exception) {
            ""
        }
    }
    fun openLink() {
        try {
            uriHandler.openUri(APP_URL)
        } catch (e: Exception) {
        }
    }

    Section(S.sAbout)
    Text("Aether", style = MaterialTheme.typography.titleLarge)
    Text(
        S.aboutApp,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
    )
    AboutRow(S.aboutVersion, version)
    AboutRow(S.aboutCreator, APP_AUTHOR)

    Label(S.aboutOrigin)
    Text(
        APP_URL,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.primary,
        textDecoration = TextDecoration.Underline,
        modifier = Modifier.clickable { openLink() }
    )
    Button(onClick = { openLink() }, modifier = Modifier.padding(top = 16.dp)) { Text(S.aboutOpen) }
}

@Composable
private fun AboutRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(
            label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.weight(1f)
        )
        Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun Section(title: String) {
    Text(
        title.uppercase(),
        style = MaterialTheme.typography.labelMedium,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 24.dp, bottom = 8.dp)
    )
}

@Composable
private fun Label(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(top = 12.dp, bottom = 6.dp)
    )
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChecked)
    }
}

@Composable
private fun <T> ChipRow(options: List<Pair<String, T>>, selected: T, onSelect: (T) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { (label, value) ->
            FilterChip(
                selected = value == selected,
                onClick = { onSelect(value) },
                label = {
                    Text(label, fontWeight = if (value == selected) FontWeight.SemiBold else FontWeight.Normal)
                }
            )
        }
    }
}
