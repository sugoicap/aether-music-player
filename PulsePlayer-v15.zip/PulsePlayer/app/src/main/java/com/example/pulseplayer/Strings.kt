package com.example.pulseplayer

import androidx.compose.runtime.compositionLocalOf

enum class Lang { HU, EN }

/** App creator shown in the About section. */
const val APP_AUTHOR = "sugoicap"
const val APP_URL = "https://github.com/sugoicap/aether-music-player"

/** All user-visible text, in the language chosen in the settings. */
class Str(val lang: Lang) {
    private fun t(hu: String, en: String) = if (lang == Lang.HU) hu else en

    // Navigation / general
    val tabLibrary = t("Könyvtár", "Library")
    val tabRadio = t("Rádió", "Radio")
    val navigation = t("NAVIGÁCIÓ", "NAVIGATION")
    val settings = t("Beállítások", "Settings")
    val menu = t("Menü", "Menu")
    val search = t("Keresés", "Search")
    val closeSearch = t("Keresés bezárása", "Close search")
    val back = t("Vissza", "Back")
    val close = t("Bezárás", "Close")
    val retry = t("Újra", "Retry")
    val exit = t("Kilépés", "Exit")
    val noResults = t("Nincs találat.", "No results.")

    // Player
    val nowPlaying = t("MOST SZÓL", "NOW PLAYING")
    val live = t("ÉLŐ", "LIVE")
    val liveRadio = t("Élő rádió", "Live radio")
    val previous = t("Előző", "Previous")
    val next = t("Következő", "Next")
    val play = t("Lejátszás", "Play")
    val pause = t("Szünet", "Pause")
    val shuffle = t("Keverés", "Shuffle")
    val repeat = t("Ismétlés", "Repeat")

    // Library
    val libArtists = t("Előadók", "Artists")
    val libAlbums = t("Albumok", "Albums")
    val libFolders = t("Mappák", "Folders")
    val libSongs = t("Összes szám", "All songs")
    fun songs(n: Int) = t("$n szám", if (n == 1) "1 song" else "$n songs")
    fun albums(n: Int) = t("$n album", if (n == 1) "1 album" else "$n albums")
    fun artists(n: Int) = t("$n előadó", if (n == 1) "1 artist" else "$n artists")
    fun folders(n: Int) = t("$n mappa", if (n == 1) "1 folder" else "$n folders")
    val unknownAlbum = t("Ismeretlen album", "Unknown album")
    val unknownArtist = t("Ismeretlen előadó", "Unknown artist")
    val variousArtists = t("Különböző előadók", "Various artists")
    val grantTitle = t("Játszd le a telefonodon lévő zenéket", "Play the music stored on your phone")
    val grantButton = t("Hozzáférés engedélyezése", "Allow access")
    val librarySearchHint = t("Szám, előadó, album vagy mappa", "Song, artist, album or folder")
    val noMusic = t("Nem található zene ezen az eszközön.", "No music found on this device.")

    // Radio
    val rFavorites = t("Kedvencek", "Favorites")
    val rCountries = t("Országok", "Countries")
    val rLanguages = t("Nyelvek", "Languages")
    val rAll = t("Összes", "All")
    val rSearchFavorites = t("Keresés a kedvencek között", "Search favorites")
    val rSearchCountry = t("Ország keresése", "Search countries")
    val rSearchLanguage = t("Nyelv keresése", "Search languages")
    val rSearchStation = t("Rádió keresése", "Search stations")
    val emptyFavorites = t(
        "Még nincs kedvenc rádiód. Keress egyet az Összes, Országok vagy Nyelvek fülön, és koppints a szívre.",
        "No favorite stations yet. Find one under All, Countries or Languages and tap the heart."
    )
    val addFavorite = t("Kedvencekhez adás", "Add to favorites")
    val removeFavorite = t("Eltávolítás a kedvencekből", "Remove from favorites")

    // Messages
    val errRadio = t(
        "Nem érem el a rádiókatalógust. Ellenőrizd a netkapcsolatot.",
        "Can't reach the radio directory. Check your connection."
    )
    fun errPlayback(code: String) = t("Lejátszási hiba: $code", "Playback error: $code")
    val playerStarting = t("A lejátszó még indul, próbáld újra", "The player is still starting, try again")
    val errService = t("Nem sikerült csatlakozni a lejátszó szolgáltatáshoz", "Couldn't connect to the audio service")
    val errLibrary = t("Nem sikerült beolvasni a zenéket", "Couldn't read your music library")

    // Settings
    val sTheme = t("Téma", "Theme")
    val sOled = t("OLED fekete", "OLED true black")
    val sAccent = t("Kiemelőszín", "Accent color")
    val sAlbumArt = t("Albumborító", "Album art")
    val sCustom = t("Egyéni", "Custom")
    val sNowPlaying = t("Lejátszó nézet", "Now playing")
    val sLayout = t("Elrendezés", "Layout")
    val sClassic = t("Klasszikus", "Classic")
    val sMinimal = t("Minimalista", "Minimal")
    val sVinyl = t("Vinyl", "Vinyl")
    fun sRadius(dp: Int) = t("Borító lekerekítése: $dp dp", "Cover corner radius: $dp dp")
    val sBlur = t("Elmosott borító háttér", "Blurred cover background")
    val sAnim = t("Számváltási animáció", "Song change animation")
    val sSlide = t("Csúszás", "Slide")
    val sFade = t("Áttűnés", "Fade")
    val sLibrary = t("Zenekönyvtár", "Music library")
    val sView = t("Nézet", "View")
    val sGrid = t("Rács", "Grid")
    val sCompact = t("Kompakt", "Compact")
    val sDetailed = t("Részletes", "Detailed")
    val sColumns = t("Rács oszlopai", "Grid columns")
    val sLanguage = t("Nyelv", "Language")
    val sAbout = t("Névjegy", "About")
    val pGeneral = t("Általános", "General")
    val pPlayer = t("Lejátszó", "Player")
    val pSound = t("Hangzás", "Sound")
    val eqTitle = t("Hangszínszabályzó", "Equalizer")
    val eqEnable = t("Bekapcsolva", "Enabled")
    val eqNote = t("A változtatás lejátszás közben azonnal hallható.", "Changes are audible right away while playing.")
    val eqPreset = t("Előbeállítás", "Preset")
    val eqCustom = t("Egyéni", "Custom")
    val eqBands = t("Frekvenciasávok", "Frequency bands")
    val eqBass = t("Mélyerősítés", "Bass boost")
    val eqReset = t("Alaphelyzet", "Reset")
    val eqUnsupported = t("Ez az eszköz nem támogatja a hangszínszabályzót.", "This device doesn't support the equalizer.")
    val aboutOrigin = t("Az app forráskódja és eredete", "Source code and origin of this app")
    val aboutOpen = t("Megnyitás GitHubon", "Open on GitHub")
    val aboutVersion = t("Verzió", "Version")
    val aboutCreator = t("Készítő", "Created by")
    val aboutApp = t("Zenelejátszó helyi zenékhez és online rádióhoz.", "Music player for local music and online radio.")
}

val LocalStr = compositionLocalOf { Str(Lang.EN) }
