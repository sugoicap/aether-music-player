package com.example.pulseplayer

import android.content.Context
import android.content.SharedPreferences
import android.media.AudioManager
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import kotlinx.coroutines.flow.MutableStateFlow

/** What this device's equalizer can do. Levels are in millibel (100 = 1 dB). */
class EqInfo(
    val minLevel: Int,
    val maxLevel: Int,
    val freqsHz: List<Int>,
    val presets: List<String>,
    val presetLevels: List<List<Int>>,
    val bassSupported: Boolean
)

data class EqState(
    val enabled: Boolean = false,
    val levels: List<Int> = emptyList(),
    val preset: Int = -1,
    val bass: Int = 0
)

/**
 * Equalizer + bass boost for the playback service. It lives in the app process, so the settings
 * screen and the service share it. The effects attach to the audio session of the player.
 */
object AudioFx {
    val state = MutableStateFlow(EqState())
    var info: EqInfo? = null
        private set

    private var prefs: SharedPreferences? = null
    private var eq: Equalizer? = null
    private var boost: BassBoost? = null

    fun init(context: Context) {
        if (prefs != null) return
        val p = context.getSharedPreferences("aether_fx", Context.MODE_PRIVATE)
        prefs = p
        info = queryInfo(context)
        val bands = info?.freqsHz?.size ?: 0
        val saved = p.getString("levels", "").orEmpty()
            .split(",").mapNotNull { it.toIntOrNull() }
        state.value = EqState(
            enabled = p.getBoolean("enabled", false),
            levels = List(bands) { saved.getOrElse(it) { 0 } },
            preset = p.getInt("preset", -1),
            bass = p.getInt("bass", 0)
        )
    }

    private fun queryInfo(context: Context): EqInfo? = try {
        val sid = (context.getSystemService(Context.AUDIO_SERVICE) as AudioManager).generateAudioSessionId()
        val e = Equalizer(0, sid)
        try {
            val bands = e.numberOfBands.toInt()
            val range = e.bandLevelRange
            val presets = (0 until e.numberOfPresets.toInt()).map { e.getPresetName(it.toShort()) }
            val presetLevels = presets.indices.map { p ->
                e.usePreset(p.toShort())
                (0 until bands).map { b -> e.getBandLevel(b.toShort()).toInt() }
            }
            val bassSupported = try {
                val b = BassBoost(0, sid)
                val ok = b.strengthSupported
                b.release()
                ok
            } catch (x: Exception) {
                false
            }
            EqInfo(
                minLevel = range[0].toInt(),
                maxLevel = range[1].toInt(),
                freqsHz = (0 until bands).map { e.getCenterFreq(it.toShort()) / 1000 },
                presets = presets,
                presetLevels = presetLevels,
                bassSupported = bassSupported
            )
        } finally {
            e.release()
        }
    } catch (x: Exception) {
        null
    }

    /** Called by the service whenever the player's audio session changes. */
    fun attach(sessionId: Int) {
        if (sessionId == 0) return
        release()
        try {
            eq = Equalizer(0, sessionId)
        } catch (x: Exception) {
            eq = null
        }
        try {
            boost = BassBoost(0, sessionId)
        } catch (x: Exception) {
            boost = null
        }
        apply()
    }

    fun release() {
        try {
            eq?.release()
        } catch (x: Exception) {
        }
        try {
            boost?.release()
        } catch (x: Exception) {
        }
        eq = null
        boost = null
    }

    fun update(s: EqState, save: Boolean = true) {
        state.value = s
        apply()
        if (save) {
            prefs?.edit()
                ?.putBoolean("enabled", s.enabled)
                ?.putString("levels", s.levels.joinToString(","))
                ?.putInt("preset", s.preset)
                ?.putInt("bass", s.bass)
                ?.apply()
        }
    }

    private fun apply() {
        val s = state.value
        try {
            eq?.let { e ->
                e.setEnabled(s.enabled)
                if (s.enabled) {
                    val n = e.numberOfBands.toInt()
                    s.levels.forEachIndexed { i, l ->
                        if (i < n) e.setBandLevel(i.toShort(), l.toShort())
                    }
                }
            }
        } catch (x: Exception) {
        }
        try {
            boost?.let { b ->
                if (b.strengthSupported) {
                    b.setStrength(s.bass.coerceIn(0, 1000).toShort())
                    b.setEnabled(s.enabled && s.bass > 0)
                }
            }
        } catch (x: Exception) {
        }
    }
}
