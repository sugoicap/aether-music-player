# PulsePlayer

An Android music player (Kotlin + Jetpack Compose + Media3) with three sources in one app:

- **Library**: music stored on your phone, search, shuffle, background playback with notification and lock-screen controls.
- **Radio**: thousands of online stations from the free [Radio Browser](https://www.radio-browser.info) directory. Search, genre chips, favorites (saved on the device), and the live song title shown when the station sends it.
- **YouTube**: your own list of YouTube songs, played through YouTube's official embedded player.

A mini player at the bottom controls whichever source is playing. Starting one source pauses the others.

## Design (v2)

- OLED true black dark theme, Inter font, accent colour from the album cover or a colour you pick.
- Now Playing screen (tap the mini player): Classic, Minimal and Vinyl layouts, blurred cover background,
  adjustable cover corner radius, waveform seek bar, time-synced lyrics (LRCLIB), slide/fade song transitions.
- Music tab: grid (2-4 columns), compact and detailed list, FLAC/MP3 + bitrate badges.
- Everything is adjustable in Settings (gear icon, top right).
- The Inter font is downloaded automatically during the build.

## Build and run

1. Install Android Studio (Ladybug or newer) and open this `PulsePlayer` folder.
2. Let Gradle sync (it downloads Gradle 8.9 and the libraries).
3. Run on a phone or emulator running Android 8.0 (API 26) or newer.

## Adding YouTube songs

- Paste a link in the YouTube tab and tap **+**, or
- In the YouTube app, open a video, tap **Share → PulsePlayer**. It is added and starts playing.

Titles and channel names are fetched automatically. The list is saved on the device.

## Things to know

- **YouTube does not play with the screen off.** Google's terms only allow the embedded player, and background playback is a YouTube Premium feature. Songs keep playing while you switch tabs inside the app. Local music and radio do play in the background.
- Some videos have embedding disabled by their owner. The app tells you and skips to the next one.
- There is no in-app YouTube search: that needs a YouTube Data API key. It can be added.
- Radio streams use plain `http` often, so cleartext traffic is enabled in the manifest.

## Project layout

```
app/src/main/java/com/example/pulseplayer/
  MainActivity.kt       entry point, handles shared YouTube links
  PlaybackService.kt    Media3 background service (local + radio)
  PlayerViewModel.kt    controls all three sources
  Data.kt               MediaStore, Radio Browser API, YouTube links, saved lists
  PulseApp.kt           navigation, mini player, YouTube player view
  LibraryScreen.kt / RadioScreen.kt / YouTubeScreen.kt
```
