package com.example.pulseplayer

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.SmartDisplay
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle

/**
 * The video itself is drawn by the persistent player view in PulseApp, which sits on top of the
 * first [topInset] of this screen.
 */
@Composable
fun YouTubeScreen(vm: PlayerViewModel, topInset: Dp) {
    val items by vm.ytItems.collectAsStateWithLifecycle()
    val now by vm.now.collectAsStateWithLifecycle()
    var link by rememberSaveable { mutableStateOf("") }

    fun submit() {
        if (link.isNotBlank()) {
            vm.addYoutube(link)
            link = ""
        }
    }

    Column(Modifier.fillMaxSize()) {
        Spacer(Modifier.height(topInset))

        Row(
            Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = link,
                onValueChange = { link = it },
                placeholder = { Text("Paste a YouTube link") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { submit() }),
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(8.dp))
            FilledIconButton(onClick = { submit() }) {
                Icon(Icons.Filled.Add, contentDescription = "Add to list")
            }
        }

        if (items.isEmpty()) {
            Text(
                "Add songs by pasting a link, or open a video in the YouTube app and tap Share → PulsePlayer.",
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                itemsIndexed(items, key = { _, entry -> entry.videoId }) { index, item ->
                    val current = now.source == Source.YOUTUBE && now.mediaId == item.videoId
                    ListItem(
                        modifier = Modifier.clickable { vm.playYoutube(index) },
                        colors = ListItemDefaults.colors(
                            containerColor = if (current) MaterialTheme.colorScheme.secondaryContainer else Color.Transparent
                        ),
                        leadingContent = { Artwork(item.thumb, 56.dp, Icons.Filled.SmartDisplay) },
                        headlineContent = { Text(item.title, maxLines = 2, overflow = TextOverflow.Ellipsis) },
                        supportingContent = {
                            if (item.author.isNotBlank()) Text(item.author, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        },
                        trailingContent = {
                            IconButton(onClick = { vm.removeYoutube(item) }) {
                                Icon(Icons.Filled.Close, contentDescription = "Remove")
                            }
                        }
                    )
                }
            }
        }
    }
}
